function i_opt = findBestResult(result_st)
%  find a group of best result
%  Inputs:
%    result_st: a struct array of the result output by   pu_predict()
%  Outputs:
%  	 i_opt: an index of the best result   
 
i_opt = [];
[n,m] = size(result_st);
temp_c = cell(n,m);
threshold_tpr_tnr = 0.2; % minimum threshold of TPR and TNR

% calculate the mean TP, FP, TN, FN
[temp_c{:,:}] = deal(result_st(:,:).TP);
tp_m  = cell2mat(temp_c);
tp_v = mean(tp_m,2);

[temp_c{:,:}] = deal(result_st(:,:).FP);
fp_m  = cell2mat(temp_c);
fp_v = mean(fp_m,2);

[temp_c{:,:}] = deal(result_st(:,:).TN);
tn_m  = cell2mat(temp_c);
tn_v = mean(tn_m,2);

[temp_c{:,:}] = deal(result_st(:,:).FN);
fn_m  = cell2mat(temp_c);
fn_v = mean(fn_m,2);

% TNR= TN/(TN+FP)
% FNR=FN/(FN+TP)
% FPR=FP/(FP+TN)
% TPR=TP/(TP+FN)
tpr_v = tp_v./max(tp_v+fn_v,1); 
tnr_v = tn_v./max(tn_v+fp_v,1);
accuracy_v = (tp_v+tn_v)./(tp_v+tn_v+fp_v+fn_v);

ind = find(tpr_v >=threshold_tpr_tnr & tnr_v>=threshold_tpr_tnr);
if isempty(ind)
    %i_opt = -1; % no qualified results
    fprintf(1,'k-fold cross validation: no qualified results found.\n');
     [~,i_opt] = max(accuracy_v);    
else
    [~,i_max] = max(accuracy_v(ind));
    i_opt = ind(i_max);
end

end