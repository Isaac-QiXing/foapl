#include "mex.h"

#define MAX_DIM 10  /* the maximum number of dimensions of A, B */
#define MAX_DIM_C 2*MAX_DIM

int weight_v_global[3][MAX_DIM_C]; 
        /* gloable variable, used for vec2scalar() */
int size_v_global[3][MAX_DIM_C]; 
    /* dimensions of multidimensional array A, B and C_virtual
       C_virtual is a virtrual multi-dimensional array */
int len_dim_global[3]; 
    /* indicate the dimension number of the four vectors, i.e. 
     *  len_dim_global[i] indicate the number of elements of weight_v_global[i],
     * i=0,1,2,3;  */

  /* MATLAB  indexing scheme: for example, consider four subscripts (i,j,k,l) 
   * into a four-dimensional array with size [d1 d2 d3 d4]. 
   *  MATLAB calculates the offset into the storage column by
   *          (l-1)*(d3)*(d2)*(d1)+(k-1)*(d2)*(d1)+(j-1)*(d1)+i  
   */

void  cal_weight_v(int *s_v, int len_dim, int *w_v)
{
    /* calculate the weight of each dimension
    *  Inputs:
    *   s_v: a vector with length len_dim_global, s_v[i] is the length of the 
    *     i-th diminsion;
    *   len_dim: the number of dimensions;
    *   w_v: a vector with length LEN_DIM,
    *      w_v[i] returns the "weigts" of the i-th dimension, 
    *       w_v[i] = s_v[i-1]*s_v[i-2]* ... * s_v[0];
    *       w_v[0] = 1;
    * Outputs:
    *   w_v  */
    
    int i;
    w_v[0] = 1;
    for(i=1;i<len_dim;i++)
    {
        w_v[i] = w_v[i-1]*s_v[i-1];
    }
}
        

int vec2sclar(int i_v[],int id)
{
    /* calculate  the linear index
    * Inputs: 
    *  i_v: the vector form index: e.g.: [1 2 1]
    *     id:  0, 1, 2 or 3, identify the multidimensional array
    * Outputs: the linear index correponding to i_v         */
    
    int *w,len,i,sc;
    w = weight_v_global[id];
    len = len_dim_global[id];
    
    sc = 0;
    for(i=0;i<len;i++){
        sc+=w[i]*i_v[i];
    }
    return(sc);    
}



void i_c_plus_one(int *p_c)
{
   /* add 1 to the indices of array C
    *  p_c:  point to the vector of containing indices of C:
    *    ---> [ i_0, i_1,... i_{i0-2}, 0, i_{i0},...,i_{p-1}, j0, ...,j_{j0-2}, 0, j_{j0}, ...j_{q-1} ]
    *  Note that 1) the vector of indices have length len_dim_global[0]+len_dim_global[1]
    *          the index vector of C has lenght len_dim_global[0]+len_dim_global[1]-2,
    *            it does not contain the i0-th and (i0+j0)-th index;
    *            (they are constanly 0, which are inserted);
    *      2) the i0-th and (i0+j0)-th index of p_c is constanly 0;  */
    
    int i;
    p_c[0]++;
    for(i=0;i<len_dim_global[2]-1;i++)
    {
        if(p_c[i]<size_v_global[2][i])
        	break;
        else /* p_c[i]==size_v_global[2][i] */
        {
            p_c[i]=0;
            p_c[i+1]++;
        }                
    }
}

void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
 /* multiply two multidimensional arrays */

/* Inputs:
*  A: a multidimensional array
*  B: a multidimensional array
* arg: Optional, a vector with two elements indicating the dimensions where
*   multiplications occur, e.g. arg = [1 2];
*       then C(i2,i3,...,j1,j3,...) = sum_{i1,j2} A(i1,i2,i3,...)*B(j1,j2,...)
*     note that the length of the given two dimensions should equal.
*       default value of arg is [1 1];
*  C: the multiplication of A and B;

* Note: a row vector is dealed with a 1-by-n  matrix;
*       a column vector is dealed wit a n-by-1 matrix;
*/
    
  int i0,j0,i,j;   
  double *arg, *A_pr, *B_pr, *C_pr;
  const mwSize *size_a,*size_b;
  int n_dim_a, n_dim_b, n_dim_c_vir,n_dim_opt;
  int *size_c, *ind_c_vir;
  int *p_a, *p_b, *p_c;
  int num_c,i_c,i_a,i_b;
  double sum_t;
  int w_i0, w_j0;
  
  /* Check for proper number of arguments.  */
  if(nrhs<2) {
    mexErrMsgTxt("At least 2 inputs are required.");
  } 
  
  /* The input must be a noncomplex scalar double. */
  if(  mxIsComplex(prhs[0]) || mxIsComplex(prhs[1]) ){
    mexErrMsgTxt("Inputs must be noncomplex arrays.");
  }

  
  /* check the argument arg */
  if (nrhs>=3 && mxGetNumberOfElements(prhs[2])!=2){
      mexErrMsgTxt("arg should be a vector with two integer elements.");
  }
          
  if (nrhs<=2){
      i0 = 1;
      j0 = 1;
  }
  else{
      arg = mxGetPr(prhs[2]);
      i0 = (int)(arg[0]);
      j0 = (int)(arg[1]);
  }
          
  size_a = mxGetDimensions(prhs[0]);
  size_b = mxGetDimensions(prhs[1]);
  n_dim_a = (int)mxGetNumberOfDimensions(prhs[0]);
  n_dim_b = (int)mxGetNumberOfDimensions(prhs[1]);    
  n_dim_c_vir = n_dim_a + n_dim_b; 
            /* dimension number of C_virtual */
  n_dim_opt = (int)size_a[i0-1]; 
            /* the length of the dimension to multiply */
  if (n_dim_a<i0) {
      mexErrMsgTxt("The first input array does not have the given dimension for multiplication.");
  }

  if (n_dim_b<j0) {
      mexErrMsgTxt("The second input array does not have the given dimension for multiplication.");
  }
  
  if ( n_dim_opt!= (int)size_b[j0-1]) {
      mexErrMsgTxt("The length of the two specified dimensions of the inputs should be equal.");
  }
  /* assign the  number of dimensions to len_dim_global */
  len_dim_global[0] = n_dim_a;
  len_dim_global[1] = n_dim_b;  
  len_dim_global[2] = n_dim_a + n_dim_b; /* number of dimensions of C_virtual */
 
  /* assign the dimensions of A, B, C and C_virtual to size_v_global */  
  size_c = mxCalloc(n_dim_a + n_dim_b-2, sizeof(int)); 
      /* assign the dimensions of A, C_virtual */
  for(i=0;i<n_dim_a;i++)
  {   
      size_v_global[0][i] = (int)size_a[i];   /* dimensions of A   */
      size_v_global[2][i] = (int)size_a[i];   /* dimensions of C_virtual */
        /* assign size_c */
      if(i==i0-1)
          continue;
      else{
          j= (i<i0-1) ? i:i-1;
          size_c[j] = (int)size_a[i];
      }
  }
  size_v_global[2][i0-1] = 1;   
        /* assign the i0-th dimension of C_virtual length 1 */
          
    /* assign the dimension of B, C_virtual */
  for(i=0;i<n_dim_b;i++)
  {
      size_v_global[1][i] = (int)size_b[i];   /* dimensions of B  */
      size_v_global[2][n_dim_a+i] = (int)size_b[i];   /* dimensions of C_virtual */
       /* assign size_c */
      if(i==j0-1)
          continue;
      else{
          j= (i<j0-1) ? i:i-1;
          size_c[n_dim_a-1+j] = (int)size_b[i];
      }
  }
  size_v_global[2][n_dim_a+j0-1] = 1; 
        /* assign the n_dim_a+j0-th dimension of C_virtual length 1 */
  
  /* allocate memory and set global variables:  weight_v_global, len_dim_global; */
  for(i=0;i<3;i++)
      cal_weight_v(size_v_global[i],len_dim_global[i],weight_v_global[i]);
  
    /* Create numeric array           */
  plhs[0] = mxCreateNumericArray(n_dim_a+n_dim_b-2, size_c,mxDOUBLE_CLASS, mxREAL);  
        /* number of dimensions of C: n_dim_a + n_dim_b-2 */
  
  /* calculate the multiplication   */
  A_pr = mxGetData(prhs[0]);
  B_pr = mxGetData(prhs[1]);
  C_pr = mxGetData(plhs[0]);
      /* initialize indices of C  */
  ind_c_vir = mxCalloc(n_dim_c_vir, sizeof(int)); /* _vir: virtual */
  for(i=0;i<n_dim_c_vir;i++) ind_c_vir[i] = 0;
  
  p_c = ind_c_vir;
  p_a = p_c;
  p_b = &ind_c_vir[n_dim_a]; /* p_b --> the (n_dim_a + 1) elements of ind_c_vir  */
  
  i_c = 0;  
  num_c = weight_v_global[2][n_dim_c_vir-1]*size_v_global[2][n_dim_c_vir-1];
                        /* number of elements of array C  */
  w_i0 = weight_v_global[0][i0-1];
  w_j0 = weight_v_global[1][j0-1];
  
  while(i_c<num_c)
  {     
      sum_t = 0;
      /* calculate the indices of A and B */
      i_a = vec2sclar(p_a,0);
	  i_b = vec2sclar(p_b,1);
      for(i=0;i<n_dim_opt;i++)
      {     
           sum_t += A_pr[i_a]*B_pr[i_b];
           /* update the indices of A and B */
           i_a += w_i0;
           i_b += w_j0;
      }      
      C_pr[i_c] = sum_t;
      i_c++;
      i_c_plus_one(p_c);
  }
  
}/* end of mexFunction */
