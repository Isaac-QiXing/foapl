function [alpha_proj]= proj_box(alpha_v, A_v,B_v)
% calculate   the projection of  alpha_v to a  box set 
%   X = { x in R^n  | A_i <= x_i <= B_i, i=1,...,n }
% Inputs:
%   alpha_v: a n-by-1 vector
%   A_v, B_v: n-by-1 vectors indicating the box set X such that  A_v(i)<=B_v(i)
%       for each i;
% outputs:
%   alpha_proj: a n-by-1 vector, the projection of alpha_v to X

% alpha_proj(i) 
%   = alpha_v(i), if alpha_v(i) in [A_v(i),B_v(i)]
%   = B_v(i), if alpha_v(i) >  B_v(i);
%   = A_v(i), if alpha_v(i) <  A_v(i);

alpha_proj = min(max(alpha_v,A_v),B_v);
 
end