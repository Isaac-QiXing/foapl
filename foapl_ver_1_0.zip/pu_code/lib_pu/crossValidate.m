function [result_opt,par_opt]= crossValidate(alg,matTrainFile, par_alg, par_search,varargin)
% a general algorithm of cross validation to choose a good group of parameter values
% Inputs:
%  alg:  function handle indicating the  algorithm object
%      The algorithm has the format
%       [result_test ] = alg(matTrainFile,matTestFile, par_alg)
%      matTrainFile, matTestFile: mat file name for traing and test,
%       it contain  the same data variables;
%      par_alg: a struct of algorithm  parameters
%      result_test: a struct of the predicted results on test sets 
%          Each field  of result_test should be a numeric scalar.
%   
%  matTrainFile: mat file name containing the  training data
%  par_alg:  a struct indicating the  parameters of function ALG;
%       note that the   parameter  that contained in PAR_SEARCH do
%       not take effects.
%  par_search:  a struct indicating the parameters to determine the numerical values by   cross validation
%  varargin: the names and values of parameters of cross validation
%    varargin{2*i-1}: a string, the argument name;
%    varargin{2*i}:  a vector indicating the   values of the argument
%     of varargin{2*i-1}; for i=1, 2, ...
%
%    supported parameters:
%       'n': a positve interger, maximum number of samples for cross
%           validation;
%           default value: the max length of matrices and vectors contained
%           in the matTrainFile;
%
%       'k': a positive integer (k>=2), number of folds;
%           default value: 5;
%       'saveFileFun': a function handle to save training or validating samples to an independent mat files.
%           The function handle has the following format:
%              saveFileFun(matFileName, matDataFileName,index_v,n)
% 
%           matFileName:     a string, mat file name to save the specified data   samples
%           matDataFileName: a string, mat file name that saved the samples
%           index_v:         a vector of indices between 1 to N, the indices of  samples to save;
%           n:               Optional, maximum number of instances for cross validation 
%
%           default function handle:
%           save  the specified indices of ALL  the matrices and vectors of lenght N contained in the matTrainFile
%           as an independent mat file; the variable names hold the same.
%       'bestResult': a function handle to find the best result with format
%           i_opt = bestResult(result_st)
%         with result_st a struct array of the result output by ALG()
%           i_opt: an index of the best result     
%         Default function handle find the maximum value of the first item of result_st 

%        
%
% Outputs:
%   result_opt: the optimal reach result on validation sets
%   par_opt: a struct indicating the parameter values with optimal accuracy
% Usage example:
%    par_search = struct( 'lambda',[0.1 1.0 5.0],'r1',[0.1 0.2 1.0]);
%    [result_opt,par_opt]= crossValidate(alg,  matTrainFile, par_alg, par_search,'k',5)
%    [result_opt,par_opt]= crossValidate(alg,  matTrainFile, par_alg, par_search)

debug_crossValidate = 0; % whether debug the function
verbose_crossVal =1; % print brief information 

% 0.1 get user provided prameters
arg = struct();
len_argin = length(varargin);
if len_argin>0
    arg = assignStruct(arg, varargin(1:2:len_argin),varargin(2:2:len_argin));
end
% set default values
arg = completeArg(arg, ...
    {'n','k','saveFileFun','bestResult'},...
    {[], 5,   @saveFileFun,   @bestResult});

fold_k = arg.k;
saveFileFun_h = arg.saveFileFun;

% 0.2 get parameter names and values for grid search
% % % 
% % % if mod(len_arg,2)~=0
% % %     error('the input parameter-values should be given as  ''parameter-1,value-1,...,parameter-N,value-N'' format)' );
% % % end
par_name_c = fieldnames(par_search);
par_val_c = struct2cell(par_search);

if debug_crossValidate
   fwritef(1,'par_name_c',par_name_c,'' ,'par_val_c',par_val_c,'');
end
    


n_parVal_v = cellfun(@length, par_val_c);
% number of tested values for each parameter
n_parVal_total = prod(n_parVal_v);
% total number of group of parameter values to test

% 0.3 initialization
len_arg = length(par_val_c); 
n_par = len_arg; % number of parameters for grid search

% % % par_name_value = cell(2*n_par,1); % parameter name and value cell
% % % par_name_value(1:2:end) = par_name_c;

% % % 
% % % arg_cross = struct();
% % % arg_cross = assignStruct(arg_cross, par_name_c,cell(n_par,1));
% % % % parameter struct of grid searching



% % % Acc_m = zeros(n_parVal_total,fold_k);  % save the accuracy on each fold
Par_c = cell(n_parVal_total,1);


% 1. assign the parameter values to test
ind_v = cell(n_par,1);
par0_c = cell(n_par,1); % store a group of parameter values
for i_par = 1:n_parVal_total
    % assign each group of parameter values
    [ind_v{1:n_par}]  = ind2sub(n_parVal_v,i_par); % ind_v: index of vector form for i_par
    % receive multiple outputs by cell array
    for k=1:n_par
        par0_c{k} =  par_val_c{k}(ind_v{k});
    end
    Par_c{i_par}= par0_c;
end

if debug_crossValidate
    fwritef(1,'Par_c',Par_c,'','par_name_c',par_name_c,'');
end

% 2. generate indices of training set and validation set

% 2.1   determine the value of N (number of total samples)
is_matrix_or_vec = @(x) (size(x,3)==1); % whether x is a 2-dimensional array
max_len_data = 0;
if isequal(saveFileFun_h,@saveFileFun)|| isempty(arg.n)
    % check the maximum size of the matrices and vectors contained in matTrainFile
    data_st = load(matTrainFile);  % load data
    v1 = structfun(@isnumeric,data_st); %
    v2 = structfun(is_matrix_or_vec,data_st); %
    ind_mat_vec = find(v1&v2);
    fieldname_c = fieldnames(data_st);
    % max length of matrices and vectors in data_st
    max_len_data = 0;
    for ii=1:length(ind_mat_vec)
        i_field = ind_mat_vec(ii);
        max_len_data = max(max_len_data,length(data_st.(fieldname_c{i_field})));
    end
    if debug_crossValidate
        fwritef(1,'max_len_data',max_len_data,'','isequal_saveFileFun',isequal(saveFileFun_h,@saveFileFun),'');
    end
end

% % % if isempty(arg.n)
% % %     n_sample = max_len_data;
% % % else % arg.n is not empty
% % %     if isequal(saveFileFun_h,@saveFileFun)  && max_len_data~= arg.n
% % %         str = 'OR supply a function handle  to save training or validating samples.';
% % %         error('specified value of ''n'' (%d) should be equal to the max length (%d) of the matrices and vectors in trainFile %s.',...
% % %             arg.n,max_len_data,str);
% % %     end
% % %     n_sample = arg.n;
% % % end

n_sample = max_len_data;

% 2.2 generate cross validation indices
index = crossValidateIndex(n_sample,fold_k,arg.n);
if n_sample<fold_k
    error('The number of training samples should greater than the number of folds.');
end
if verbose_crossVal>0
    fprintf(1,'Cross validation: %d-fold, %d-group of parameters.\n',fold_k,n_parVal_total);
end

% 3.  k-fold  cross validation to find a group of good parameter values

date_str = datestr(now,30);
%path_str = [pwd filesep];

[path_str,dataset_name,~] =  fileparts(matTrainFile);
path_str = [path_str filesep];

matTrainFile_split = [path_str date_str '_' dataset_name '_crossVal_train.mat'];
matValidateFile_split =  [path_str date_str '_' dataset_name '_crossVal_validate.mat'];
% % % matScoreFile = [path_str date_str '_crossVal_score.mat'];

bestResult_h = arg.bestResult;

% 1st search: loose grid search
i_parVal_start =1; 
i_parVal_end = n_parVal_total;
[i0_opt] = grid_search(i_parVal_start,i_parVal_end);

% ========= for future version ===
% % 2nd search: detailed grid search
% if ~isempty(i0_opt)
%     if verbose_crossVal
%         fprintf(1,'2nd search: detailed grid search.\n');
%     end
%     % determine the values of searching parameters    
%     
%     % ........
%     % ....
%     i_parVal_start =i_parVal_end + 1; 
%     i_parVal_end = ....  
%     [i_opt] = grid_search(i_parVal_start,i_parVal_end);
% end
% =====================================

i_opt = i0_opt;
if ~isempty(i_opt) && i_opt>0 % i_opt ==-1: no qulified  results found
    result_opt = result_st(i_opt,:);
    par_opt = par_alg_st(i_opt);
else
     result_opt = [];
    par_opt = [];
end

matResultFile =  [path_str 'result_crossVal_' dataset_name '_' date_str '.mat'];
 
save(matResultFile,'par_alg_st', 'result_st', 'i_opt','par_opt','result_opt','n_parVal_total','matTrainFile','par_alg', 'par_search');
 
if verbose_crossVal
    fprintf(1,'optimal parameter and results:\n');
    fwritef(1,'par',par_opt,'');  
    fprintf(1,'The cross-validation results have been saved to %s.\n', matResultFile);
end


% delete tempary files
if exist(matTrainFile_split,'file')
    delete(matTrainFile_split);
end
if exist(matValidateFile_split,'file')
    delete(matValidateFile_split);
end
 

% * print out the results to Excel file
resultFile = [path_str 'result_crossVal_' dataset_name '_' date_str '.xlsx'];
start_row_body = '6'; % start row of the main results
sheetName = 'sheet1'; 
% *.01 print out train file name 
xlswrite(resultFile,  {matTrainFile,date_str},'A1:B1',sheetName);
% *.02 print out the best parameter: 
xlswrite(resultFile, { 'Best parameter index:' ,i_opt},'A2:B2',sheetName);
fwritexls(resultFile, {}, par_opt,'A3',sheetName,'h');

% *.1 print out the parameters: par_alg_st 
%%par_alg2_st(n_parVal_total*fold_k) = par_alg_st(1);

par_alg2_st(1:fold_k:n_parVal_total*fold_k) = par_alg_st;


% % % par_alg_c = struct2cell(par_alg_st);
% % % par_alg_c = squeeze(par_alg_c);  % size of par_alg_c:  number of parameters- by - n_parVal_total 
% % % % % % %%%
% % % % % % size(par_alg_st)
% % % % % % size(par_alg_c)
% % % % % % %%%
% % % 
% % % par_alg2_c  = cell(n_parVal_total*fold_k,size(par_alg_c,1)); % insert many empty cell for printing 
% % % par_alg2_c(1:fold_k:end,:) = par_alg_c'; 

% % % [coverSize] = fwritexls(resultFile,fieldnames(par_alg_st),par_alg2_c,['A' start_row_body],sheetName,'h');

% ----- for future version -
%id_c = cell(n_parVal_total*fold_k,1);
%id_c(1:fold_k:n_parVal_total*fold_k) = num2cell(1:n_parVal_total)';
%fwritexls(resultFile,{'id'},id_c,['A' start_row_body],sheetName,'h');
% -----
[coverSize] = fwritexls(resultFile,'',par_alg2_st,['B' start_row_body],sheetName,'h');

% *.2 print out the results: result_st
startCell =   [char('B'+ coverSize(2)) start_row_body];
fwritexls(resultFile, '', reshape(result_st',[],1),startCell,sheetName,'h');

if verbose_crossVal
    fprintf(1,'The cross-validation results have been put out to %s.\n', resultFile);
end

 



    function [i0_opt] = grid_search(i_parVal_start,i_parVal_end)
        % grid search 
        % i_parVal_start: starting index of the parameter to search
        % i_parVal_end: ending index of the parameter to search
        
        for i_fold = 1:fold_k
            if verbose_crossVal > 0
                fprintf(1,' fold %d/%d:\t',i_fold,fold_k);
            end
            % 3.1  % save the data to tempary train file and validation file
            saveFileFun(matTrainFile_split,    matTrainFile,  index(i_fold).train);
            saveFileFun(matValidateFile_split, matTrainFile,  index(i_fold).test);
            % 3.2  loop all the parameter  values
% % %             %for i_par = 1:n_parVal_total
            for i_par = i_parVal_start :i_parVal_end
                if verbose_crossVal > 0
                    fprintf(1,'+');
                end
                % set the values of the group of parameters
                par0_c = Par_c{i_par} ;
                %  assign the parameter struct
                if i_fold==1
                    par_alg_ii = completeArg(par_alg,  par_name_c,    par0_c,[],1);
                    % compulsory assignment:
                    %    all the ITEMs of par_alg specified in par_name_c would be reset as the values
                    %    of par0_c
                    %%%if i_par==1
                    if i_par==i_parVal_start
                        par_alg_st(i_parVal_end) = par_alg_ii; % initialize the struct array
                    end
                    par_alg_st(i_par) = par_alg_ii;
                else%  i_fold>1
                    par_alg_ii = par_alg_st(i_par);
                end
                
                [result_0] = alg(matTrainFile_split,matValidateFile_split, par_alg_ii);
                
                %%%if i_par==1 && i_fold==1
                if i_par==i_parVal_start && i_fold==1
                    % initialize num_st
                    %%%result_st(n_parVal_total,fold_k) = result_0;
                    result_st(i_parVal_end,fold_k) = result_0;
                end
                result_st(i_par,i_fold) = result_0;
            end % end loop of parameters
            if verbose_crossVal > 0
                fprintf(1,'\n');
            end
        end % end loop of i_fold
        
        i0_opt =  bestResult_h(result_st);        
    end
        
end

function n_saved_var = saveFileFun(matFileName, matDataFileName,index_v)
% save  the specified indices of ALL  the matrices and vectors of lenght N contained in the matTrainFile
%           as an independent mat file; the variable names hold the same.
%   matFileName: a string, mat file name to save the specified data   samples
%   matDataFileName: a string, mat file name that saved the samples
%   index_v: a vector of indices between 1 to N, the indices of  samples to save;
% Outputs:
%   n_saved_var, Optional, number of saved  variables of data matrices and
%       vectors

debug_crossValidate = 0; 
    
    is_matrix_or_vec = @(x) (size(x,3)==1); % whether x is a 2-dimensional array
    data_st = load(matDataFileName);  % load data
    v1 = structfun(@isnumeric,data_st); %
    v2 = structfun(is_matrix_or_vec,data_st); %
    ind_mat_vec = find(v1&v2);
    fieldname_c = fieldnames(data_st);    
    
    if isempty(ind_mat_vec)
        error('No data matrix or vector found in the specified file %s',matDataFleName);        
    end
    % get size of data matrices and vectors
    size_data_v = zeros(length(ind_mat_vec),2); % size of each data matrix and vector
    for ii=1:length(ind_mat_vec)
        i_field = ind_mat_vec(ii);
        size_data_v(ii,:) = size(data_st.(fieldname_c{i_field}));
    end
  
    % get the index of fileds that achive the maximum data length
    max_len_data = max(max(size_data_v));
    ind_max_len_data = ind_mat_vec(max(size_data_v,[],2) == max_len_data);
     
    if debug_crossValidate
        fwritef(1,'max_len_data',max_len_data,'','size_data_v',size_data_v,'','ind_max_len_data',ind_max_len_data,'');
    end 

    n_saved_var = length(ind_max_len_data);
    for ii=1:n_saved_var
        i_field = ind_max_len_data(ii);
        is_1_dim_reach_max_len =  size_data_v(i_field,1) == max_len_data;
        if is_1_dim_reach_max_len
            data_st.(fieldname_c{i_field}) = data_st.(fieldname_c{i_field})(index_v,:);
        else % the 2nd dimension has max length
            data_st.(fieldname_c{i_field}) = data_st.(fieldname_c{i_field})(:,index_v);
        end
    end
        
    % save the data matrices and vectors to file
    save(matFileName,'-struct','data_st');      
end


function i_opt = bestResult(result_st)
%  default function handle to  find the maximum value of the first  item of result_st
%  Inputs:
%   result_st: a struct array size n_parVal_total  * k_fold   of the result output by ALG()
%  Outputs:
%   i_opt: an index of the best result     

    i_opt = [];
    names = fieldnames(result_st);
    [n_result,k] = size(result_st);
    result_c = cell(n_result,k);
    if ~isempty(names)
        [result_c{:,:}] = result_st(:,:).(names{1});
        result_m = cell2mat(result_c);
        [~,i_opt] = max(mean(result_m,2));
    end    
end

