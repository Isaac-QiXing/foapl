 function [result_test ] = pu_predict(matTrainFile,matTestFile, par_alg)
%      matTrainFile, matTestFile: mat file name for traing and test,
%       it contain  the same data variables;
%      par_alg: a struct of algorithm  parameters
%      result_test: a struct of the predicted results on test sets 
%          Each field  of result_test is a numeric scalar.

% set the parameter values 
userSetting(par_alg);

% training the PU learning model, and predict the samples on the test set
date_str = datestr(now,30);
path_str = [pwd filesep];
matScoreFile = [path_str date_str '_crossVal_score.mat'];
foapl_solve('-f','2', matTrainFile,matTestFile,matScoreFile);
 
% calculate the average accuracy on validation sets        
sc = load(matScoreFile, 'score_test');
data_test = load(matTestFile,'y');
[~,num]  = accuracyIndex_0(sc.score_test,data_test.y);
result_test = num;
if exist(matScoreFile,'file')
    delete(matScoreFile);
end
end