function    [y_pu,ind_train] =  pu_label(y,classPrior)
% generate labels of PU-learning instances
% Inputs:
%   y: a column vector of the labels of classical binary classification  problem
%   classPrior: a constant sclar in (0,1) in dicating the weight of the
%      positive distribution in the missing labels
% Outputs:
%   y_pu: a column vector with the length less than or equal to y,
%       consisting of 1 and -1  with -1 indicating a missing label.
%   ind_train: a clumn vector of 1 or 0 with the same size as y, 
%      1: indicating the instance is selected as training
%  NOTE that y_pu ~= y(ind_train), since part of +1 labels are 
%   missing and labeled -1; 

ind_pos_v = find(y==1) ;
ind_neg_v = find(y==-1);

n_pos = length(ind_pos_v); % total number of positive instances for training 
n_neg = length(ind_neg_v); % total number of negative instances for training 

if n_pos<1 || n_pos>=length(y)
    error('No positive or negative instances provides');
end
if n_pos + n_neg < length(y)
    error('The labels should be a vector with elements of 1 or -1.');
end


n_pos_pu = floor(0.5 * n_pos); %   number of positive instances for PU learning
n_unlabel_pu = floor(min(n_neg/(1-classPrior),(n_pos-n_pos_pu)/classPrior));
    % number of unlabeled instance for PU learning
n_pos_mixture = floor(n_unlabel_pu * classPrior);
    % number   positive instances cantained in the unlabeled instances
n_neg_mixture = floor(n_unlabel_pu * (1-classPrior));
    % number   negative instances cantained in the unlabeled instances

ind_pos_perm   = randperm(n_pos, n_pos_pu+n_pos_mixture);
ind_neg_perm = randperm(n_neg,n_neg_mixture);

ind_train = columnVec([ind_pos_v(ind_pos_perm); ind_neg_v(ind_neg_perm)] );
y_pu =   [ones(n_pos_pu,1); -1* ones( n_pos_mixture+ n_neg_mixture,1) ];
 
    
end