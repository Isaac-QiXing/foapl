function size_cover = fwritexls(fileName,varargin)
% write data to xls file
% usage:
%   fwritexls('test.xls',{'name','val'},rand(5,2));
%   fwritexls('test.xls',{'name','val'},rand(5,2),'A2');
%   fwritexls('test.xls',{'name','val'},rand(5,2),'A2','test1');
%   fwritexls('test.xls',{'name','val'},rand(5,2),'A2','test1',arg);
%      where
%      arg = 'v'; indicates  the labels are arranged vertically;
%   fwritexls('test.xls',{'name','val'},rand(5,2),'','test1',...
%               {'name','val'},rand(5,2),'','test2');
%   fwritexls('test.xls',{'name','val'},rand(5,2),'','test1',...
%               {'name','val'},rand(5,2),'','test2',arg);
%   arg = 'hv'; indicates  the labels 'name', 'val' are arranged
%       1) horizontally for the first group of data
%        2) vertically for the second group of data;
%  
%  More examples.
%   str_c = {'Bob',78;
%          'Tony Cai', 89;
%          'Labneiz', 95;};
%  data_st = struct('name',{'Bob','Newton','Fermat','Pascal'},'grade',{50,85,96,97});     
%      
% fwritexls(fileName,{'Name'; 'Grade'},str_c,'A1','test5' );
%    % print out a cell matrix, each cell is a string or a number scalar
%    % note that {'Name'; 'Grade'} is a 2-by-1 column cell array
%    
% fwritexls(fileName,{'This is a description text for the data.'},data_st,'A1','test7' );
%    % print out a struct vector, each item is a numeric scalar 
%
% Inputs:
%   fileName:  xls file name
%   varargin: for i=0,1,...
%     varargin{4*i+1}: a string or string cell vector or a numeric vector for the title line
%     varargin{4*i+2}: data to print, could be
%       1) simple data type, i.e.
%          * a matrix or a vector, or
%          * a cell matrix with  each cell containing a single element 
%          * a struct with each item a vector with the same length
%          * a struct vector with the each item a scalar
%       2) or a composite data type, i.e.
%          * a cell vector with each cell a variable of simple data type
%    varargin{4*i+3}: the sheet name of the xls file for print
%    the last optional input: style of labels and data, 
%       a string consisting of 'h','v' or 'd'       
%       h: horizontally, 
%       v: vertically;
%       d: diagonally;
%       h:   ======= label  =========
%            ------------------------
%            --------Data -----------
%            ------------------------
%       v:   
%            ||  ------------------------
%  label---> ||  --------Data -----------
%            ||  ------------------------
%       d:   
%
%       label   
%       =====
%             ------------------------
%             --------Data -----------
%             ------------------------
%    varargin{4*i+4}: the left-top cell  of the range in xls file for print,
%           if set empty, it will be assign 'A1'; 
% Outputs:
%   size_cover: a 2-by-1 vector, indicating the size of the written area
%       of the LAST group of data
% Limits:
%  Current version do not check the legality of the input data to print;
%   users have to ensure that the input data in one kind of those listed in
%   the description of varargin{4*i+2};
% 
% Version history:
%   2018.8.11 to fix a bug to print a cell vector with empty elements  (for future)
% -------------
%  n_parVal_total=10;
%  fold_k=3;
% id_c = cell(n_parVal_total*fold_k,1);
% id_c(1:fold_k:n_parVal_total*fold_k) = num2cell(1:n_parVal_total)';
% fwritexls('temp2.xlsx',{'id'},id_c,['A1' ],'sheet1','h');% 
% fwritexls('temp2.xlsx',{'id'},id_c,['A1' ],'sheet2','v');
% ------------------
%   2017.3.  finish the 1st version.


isSingleNumStr = @(var) isscalar(var)&&isnumeric(var)||ischar(var);
% check whether var is a single number or a single string
%   if this is the case, flag =1; otherwise flag = 0;
isSimple = @(X) (isnumeric(X))|| iscell(X)&&nnz(cellfun(isSingleNumStr,X))== numel(X);
    

argStyle = '';
if nargin-1>4 && mod(nargin-1,4)==1
	argStyle = strtrim(varargin{nargin-1}); % the last optional input    
end

if nargin-1>=4
    num = floor((nargin-1)/4)-1;
else 
    num = 0;
end
for ii=0:num
    % the label vector
    label_v = varargin{4*ii+1};
    if ~isempty(label_v)&&~isvector(label_v)
        warning('The label inputs should be a string or numeric vector.');
        label_v = label_v(1);
    end
    % the data
    X = varargin{4*ii+2};
    % sheet name
    sheetName = '';
    if 4*ii+4<=nargin-1
        sheetName = varargin{4*ii+4};
    end
    if isempty(sheetName)
        sheetName = 'sheet1'; % default sheet
    end
    % start cell
    start_cell = '';    
    if 4*ii+3<=nargin-1
        start_cell = varargin{4*ii+3};
    end    
    if isempty(start_cell)
        start_cell = 'A1'; % left-top cell of xls file of default range 
    end
    
    % label style
    labelStyle = 'h';
    if length(argStyle)>=ii+1 % note that ii coumnts from 0;
        labelStyle = argStyle(ii+1);
    end

    switch lower(labelStyle)
        case 'h'
            flag_style = 1;
        case 'v'
            flag_style = 2;
        case 'd'
            flag_style = 3;
        otherwise
            flag_style = 1; % default value
    end
    
    % determine if the  data type is simple     
    flag_simple = 1; 
    if iscell(X) && ~iscellstr(X)
        flag_simple = isSimple(X);
        % if X is cell array and has a cell containing 
        %   not a single string or numeric, then X is complecated type;        
    end
    
    size_label_v = size(label_v); 
    if flag_simple
             % print the labels           
        if ~isempty(label_v)     
            if ischar(label_v)
                size_label_v = [1 1]; % a char string occupies just one cell;
                label_range_str = rangeStr(start_cell,size_label_v,flag_style);  
                xlswrite(fileName,{label_v},sheetName,label_range_str);
                    % {label_v}: enclose the string as a 1-by-1 cell for
                    % writing to xls
            else            
                [label_range_str i_transpose]= rangeStr(start_cell,size_label_v,flag_style);        
                if i_transpose
                    label_v = label_v';
                    size_label_v = size(label_v);
                end 
                xlswrite(fileName,label_v,sheetName,label_range_str);
            end
        end
        size_cover = size_label_v;
        if isempty(X) % the data isempty
            continue
        end    
        % determine the range of the data
        if isempty(label_v)
            data_start_cell = start_cell;
            % if label_v is empty; print the data from original
            %   starting cell
        else
            data_start_cell = cellAdd(start_cell,size_label_v,inverseStyle(flag_style));
            % inverseStyle(): the style to calculate the data range is
            %   opposite with the label style            
        end    
        
        if isempty(X) % the data isempty
            continue
        end    
        % print the data
        if iscell(X)||isnumeric(X)
            if length(X)>1
                [data_range_str flag_transpose]= rangeStr(data_start_cell,size(X),size(label_v));                
            else %length(X) == 1
                [data_range_str flag_transpose]= rangeStr(data_start_cell,size(X),inverseStyle(flag_style));
                        % inverseStyle(flag_style): data style is opposite
                        % with the labels
            end
            if flag_transpose
                    X = X';
            end
            xlswrite(fileName,X,sheetName,data_range_str);   
            % assign the size of range written by the labels and data  
            size_cover = addSize(size_cover,size(X),flag_style);
        elseif ischar(X)
            size_X = [1 1]; % a string covers just one cell
            [data_range_str]= rangeStr(data_start_cell,size_X,1);
            xlswrite(fileName,{X},sheetName,data_range_str);   
                % {X}: enclose the string as a 1-by-1 cell for writing to
                % xls file
            % assign the size of range written by the labels and data  
            size_cover = addSize(size_cover,size_X,flag_style);
        elseif isstruct(X)            
            fieldName_cell = fieldnames(X);
            if ~isscalar(X) % X is a struct array;  %isSimple(X1)                           
                X1 = struct2cell(columnVec(X)); 
                    %columnVec(X): make X a column cell array
                if ~isSimple(X1)
                    X1 = cellfun(@myswritef,X1,'UniformOutput',false);
                    % if X is a struct array, and  some item values are not
                    % a scalar number; then transform these item values as 
                    % a string;            
                end
                size_cover_sub = fwritexls(fileName,fieldName_cell,X1,...
                    data_start_cell,sheetName,labelStyle);
                size_cover = addSize(size_cover,size_cover_sub,flag_style);
            else % X is a scalar struct 
                % print the data in each field of the struct
                for ind = 1:length(fieldName_cell)
                    size_cell = fwritexls(fileName,fieldName_cell(ind),...
                        X.(fieldName_cell{ind}),data_start_cell,sheetName,labelStyle);                      
                    data_start_cell = cellAdd(data_start_cell,size_cell,flag_style); % for the next field
                    % count size_cover
                    size_cover = addSize(size_cover,size(X),flag_style);
                end                
            end
        end
    else    % deal with the composite data
        if ~isempty(label_v) && ischar(label_v)
            label_v = {label_v};            
        end
        p_start_label = start_cell;
        size_cover = [0 0];
        for ind = 1:numel(X)
            % print the label
            if ind<=length(label_v)
                if iscell(label_v)
                    label_item = label_v{ind};
                else
                    label_item = label_v(ind);
                end
                if ischar(label_item)
                    label_item = {label_item};
                end
                % get range
                [label_range_str i_transpose]= rangeStr(p_start_label,size(label_item),flag_style);        
                if i_transpose
                    label_item = label_item';                    
                end 
                size_label_item = size(label_item);
                % print label_item
                xlswrite(fileName,label_item,sheetName,label_range_str);
            else
                size_label_item = [0 0];
            end
            size_cover_cell = size_label_item;
            
            % determine the range of the data             
            p_start_data = cellAdd(p_start_label,size_label_item,inverseStyle(flag_style));
                % inverseStyle(): the style to calculate the data range is
                %   opposite with the label style                
            % print the corresponding data
        	size_cell = fwritexls(fileName,'',X{ind},p_start_data,sheetName,labelStyle);
            % update p_start_label, size_cover 
            p_start_label = cellAdd(p_start_label,size_cell,flag_style); % for the next element
            size_cover_cell = addSize(size_cover_cell,size_cell,inverseStyle(flag_style)); 
                    % the size covered by the ind-th label and data 
            size_cover = addSize(size_cover,size_cover_cell,flag_style);
                    % the size covered by the 1 to ind-th label and data
                    % cell                    
        end
    end
end % end ii
    
end % end function


function [range_str flag_transpose] = rangeStr(start_cell,size_range,argArrange)
% generate teh range string such as 'A2:B5';
% Inputs: 
%   start_cell: the left-top cell of the range
%   size_range: a vecter with two elements, indicating the size of the range
%   argArrange: 
%       1) 1: arrange the contents horizontally, only effect when
%            size is [n 1] or [1 n]
%       2) 2: arrange the contents vertically, only effect when
%            size is [n 1] or [1 n]
%       3) a vector two elements, at least one of them 1:
%           try to match the given size automatically, e.g.,
%           rangeStr('A1',[2 3],[1 2]) --> range_str: 'A1:B3', 
%                flag_transpose: 1 :  
%                           *  *     (1-by-2) given
%                           -  - 
%                           -  - 
%                           -  -     (3-by-2) match automatically
%                                       (original: 2-by-3)
%                           
%  Outputs: 
%   range_str: the range string
%   flag_transpose: 1 or 0, indicate whether it's required to transpose the
%       'size' for accomodate the size provided by argArrange (in the third
%       case); 

flag_transpose = 0;
if min(size_range)==1 && isscalar(argArrange) % row vector area and argArrange == 1 or 2
    if argArrange ==1 % arrange horizontally
        if size_range(1)>1
            size_range = swap(size_range);            
            flag_transpose = 1;
        end
    else % argArrange ==2: arrange vertically
        if size_range(2)>1
            size_range = swap(size_range);            
            flag_transpose = 1;
        end        
    end    
elseif ~isscalar(argArrange) && length(argArrange) == 2
    % match the range automatically
    s_v = size_range == max(argArrange);
    if nnz(s_v)==1 && size_range(1)~=argArrange(1) && size_range(2)~=argArrange(2)
        % nnz(s_v) == 1: just one of the dimension length match
        %    argArrage size
        size_range = swap(size_range);
        flag_transpose = 1;
    end
end
stop_cell = cellAdd(start_cell,size_range-1,3); %3: along diagonal direction
range_str = [start_cell ':' stop_cell];
end

function v = swap(v)
% v is a two-element vector
% swap the two elements: v(1) <--swap--> v(2)
a = v(1);
v(1) = v(2);
v(2) = a;
end

function new_cell = cellAdd(start_cell,size_range,flag_style)
% calculate the new_cell after moving a range based on a start_cell
% Inputs:
%  start_cell: start cell string
%  size_range: a vector of  two integers, indicating the size of the range
%      to move; 
%  rangeStyle: 
%       1: move horizontally ('h'); 
%       2: move vertically ('v');
%       3: move along diagnal direction ('d');
%       E.g.   'A1' ----(2-by-3)-'h'---> 'D1'; 
%              'A1' ----(2-by-3)-'v'---> 'A3'; 
%              'A1' ----(2-by-3)-'d'---> 'D3';
%  Outputs:
%  new_cell: string indicating the new cell

% split the cell
[col_str row_int] = getRowCol(start_cell);
switch flag_style
    case 1 % horizontally
        new_col_str = add_p_bit(col_str,size_range(2));
        new_cell = [new_col_str num2str(row_int)];    
    case 3 % along diagnal direction
        new_col_str = add_p_bit(col_str,size_range(2));
        new_cell = [new_col_str num2str(row_int+size_range(1))];
    otherwise     % vertically
        new_cell = [col_str num2str(row_int+size_range(1))];    
end        
end % end function cellAdd()

function [col_str row_int] = getRowCol(start_cell)
% split the cell string such as 'AB3' to column string (e.g., 'AB'), and row
% number (e.g., 3).
start_cell = upper(strtrim(start_cell));
s1 = regexp(start_cell, '[A-Z]');
p = max(s1);
col_str = start_cell(1:p);
row_int = str2num(start_cell(p+1:length(start_cell)));
end

function p_str2 = add_p_bit(p_str,dec)
%  p_str2 (26 carry bit string) <-- p_str (26 carry bit string) + dec (10 carry bit)
p_str2 = dec2p(p2dec(p_str) + dec);
end

function dec = p2dec(p_str)
% a 26 carry bit number (represent by a string, e.g. 'AD') --> 10 carry bit
%   number
% Inputs:
%   p_str: a string indicating a 26 carry bit number made up  of 'A' -- 'Z'
% Outputs:
%   dec: the 10 carry-bit number
p = 26; % p carry bit
p_v = int32(p_str); % note that the ASCII of 'A': 65
p_v = p_v - 64;    % 'A' <---> 1, ...., 'Z' <---> 26

dec = 0;
base = 1;
len_p = length(p_v);
for ii=1:len_p    
    dec = dec + p_v(len_p+1-ii)*base;
    base = base*p;
end
end

function p_str = dec2p(dec)
% translate a positive number of 10 carry bit to one of 26 carry bit
% Inputs:
%   dec: a 10 carry-bit number
% Outputs:
%   p_str: the string indicating a 26 carry bit number made up  of 'A' -- 'Z'
p_v = [];
p = 26;

while dec>0
    coef = mod(dec,p);
    if coef==0
        coef = p; % 'Z' <--> 26
    end
    p_v = [coef p_v];
    dec = round((dec-coef)/p);
end

p_str = char(p_v + 64); % note that 'A'<--> 1, and the ASCII of 'A' is 65;
end


function flag_inverse = inverseStyle(flag_style)
% inverse style
%  if flag_style = 1 (or 'h'), return 2 (or 'v');
%   if 2 (or 'v'), return 1 (or 'h');
%   if 3 (or 'd'), return 3 (or 'd');
%  otherwise return 2 (or 'v'); (default);
if ischar(flag_style)
    switch lower(flag_style)
        case 'h'
            flag_inverse = 'v';
        case 'v'
            flag_inverse = 'h';
        case 'd'    
            flag_inverse = 'd';
        otherwise
            flag_inverse = 'v';
    end
else
    switch flag_style
        case 1
            flag_inverse = 2;
        case 2
            flag_inverse = 1;
        case 3    
            flag_inverse = 3;
        otherwise
            flag_inverse = 2;
    end
end
end

function size1 = addSize(size0,size_range,flag_style)
% add size_range onto size0
switch flag_style
    case 1
        size1 = [size0(1) + size_range(1);
                 max(size0(2), size_range(2))];    
    case 3    
        size1 = [size0(1) + size_range(1);
                 size0(2) + size_range(2)];
    otherwise % 2
        size1 = [max(size0(1),size_range(1));
                 size0(2) + size_range(2)];
end
end

function str = myswritef(x) 
    % if x is not a scalar number or a string, print it as a string
    % otherwise return x;
    if (isscalar(x) && isnumeric(x)) || ischar(x)
        str = x;
    else
        str = swritef('',x,'','-rowvector');
    end
end
