function str = swritef(varargin)
% write some variables to a string
% Input Arguments:
%   varargin: in the form: {labelOfVar1,var1,'format1', labelOfVar2, var2,'format2',...,parameterStr}
%           the default format of variables which type is 'double' is
%           '%8.4f\t'
%     the variable can be 
%        (1)  a (real or complex) matrix 
%        (2)  a string or a numeric scalar
%        (3)  a string/numeric cell matrix, with each cell consisting of a 
%               single string or each cell consisting of a numeric,
%               indicated by the format 'c' 
%        (4)  a structure (or strcture array) with  the value of each
%               fields described by (1) -- (2) 
%        (5)  a cell array with each cell described by (1) -- (2)
%   Format: may 
%       (1) a format string: apply the formats for printing each elements; for
%           instance '%d\t', '%.2f\t';
%       (2) '': determine the formats automatically;
%       (3) '***': indicating the variable is a string/numeric cell matrix;
%               '***' indicates a format string for printing each elements,
%               for instance '%d\t' indicate printing each element with
%               format '%d\t'; 
%  ParameterStr: Optional,
%       The last input can be a parameter (string) indicating some style 
%           for put out:
%       '-rowVector': put out all numeric vector values as row vectors
%          regardless it is a column or a row vector;
% Outputs:
%   str: the output string

str = '';

% whether to put out the numeric vector values as row vector
flag_rowVector = 0; 
option_str = '';
if mod(nargin-1,3)==0 && ~isempty(varargin{end})
    option_str = varargin{end};
    flag_rowVector = strcmpi(option_str,'-rowvector');       
end

for i=1:3:nargin-1
    nm=varargin{i};
    var=varargin{i+1};
    format=varargin{i+2};    
    % print variable name
    if ~isempty(nm) && (ischar(var)||isnumeric(var))
        str = [str  sprintf('%s',nm)];
        str = [str  sprintf('\t')];
    end    
        % construct a temparary varable NM1: add a tab space before NM
    if iscell(var)
        nm1 = sprintf('\t');
        if isempty(strtrim(nm))
            nm1 = sprintf('\t%s',nm);
        end
    end    
    %print variable values
    if ischar(var)
        if strcmp(format,'')
            format= '%s';
        end
        str = [str  sprintf(format,var)];
        %str = [str  sprintf('\n');       
    elseif isnumeric(var)
        if isempty(format)
            if isIntegerVal(var)
                format = '%d\t';
            elseif isreal(var)
                format= '%8.4f\t';
            else % iscomplex
                format = '%.3f + %.3fi\t';
            end
        end    
        % deal the case: flag_rowVector==1
        if flag_rowVector && isvector(var) && size(var,1)>1
                % var is a column vector
            var = var';
        end
        row_num = size(var,1);
        for dim=1:row_num
            if isreal(var)
                str = [str  sprintf(format,var(dim,:))];
            else                
                str = [str  sprintf(format,real(var(dim,:)),imag(var(dim,:)))];
            end
            str = [str  sprintf('\n')];
        end
    elseif isstruct(var)
        fn = fieldnames(var);        
        if length(var)==1
            % put out the names and values of each fields            
            for ii=1:length(fn)
                nm1 = sprintf('%s.%s',nm,fn{ii});                    
                str = [str  sprintf('%s\t= ',nm1)];
                if isstruct(var.(fn{ii})) || iscell(var.(fn{ii}))
                    str = [str  sprintf('\n')];
                    nm1 = sprintf('\t%s',nm1);                    
                    str = [str swritef(nm1,var.(fn{ii}),format,option_str)];
                else                    
                    str = [str swritef('',var.(fn{ii}),format,option_str)];                     
                end                
            end
        else
            size_v = size(var);
            n = length(size_v);
            if n==2 && (size_v(1)==1 || size_v(2)==1) % var is a one-dimensional struct array 
                % reset N and SIVE_V
                n=1;
                size_v = length(var);
            end
            ind = 0;                        
            while 1
                v = decimal2general(size_v,ind);
                if v(n)>=size_v(n) % size_v: from left to right: low dight --> high digit
                    break;
                end
                % put out the values of each fields                
                for ii=1:length(fn)                                        
                    nm1 = sprintf('%s(',nm);
                    if n>1
                        nm1 = strcat(nm1,sprintf('%d,',v(1:n-1)+1));
                    end
                    nm1 = strcat(nm1,sprintf('%d)',v(n)+1),sprintf('.%s',fn{ii}));                    
                    str = [str  sprintf('%s\t= ',nm1)];
                    if isstruct(var(ind+1).(fn{ii})) || iscell(var(ind+1).(fn{ii}))
                        str = [str  sprintf('\n')];
                        nm1 = sprintf('\t%s',nm1);
                        str = [str swritef(nm1,var(ind+1).(fn{ii}),format,option_str)];
                    else
                        str = [str swritef('',var(ind+1).(fn{ii}),format,option_str)];                     
                    end
                    str = [str  sprintf('\n')];
                end
                ind = ind + 1;
            end
        end
    elseif iscell(var)        
        if length(var)==1
            % put out the value of the cell            
            if ~isempty(strtrim(nm))
                str = [str  sprintf('%s =\n',nm)];
            else
                str = [str  sprintf('%s',nm)];
            end
            str = [str swritef(nm1,var{1},format,option_str)];            
        else
            size_v = size(var);
            n = length(size_v);
            if n==2 && (size_v(1)==1 || size_v(2)==1) % var is a one-dimensional cell array 
                % reset N and SIVE_V
                n=1;
                size_v = length(var);
            end
            ind = 0;                        
            while 1                
                v = decimal2general(size_v,ind);
                if v(n)>=size_v(n)
                    break;
                end
                % put out the values of each cell
                str = [str  sprintf('%s{',nm)];
                if n>1
                    str = [str  sprintf('%d,',v(1:n-1)+1)];
                end
                str = [str  sprintf('%d} = \n',v(n)+1)];                
                str = [str swritef(nm1,var{ind+1},format,option_str)]; 
                ind = ind + 1;
            end
        end        
    end
end
end % end of the function fwritef()

function  v = decimal2general(size_v,ind)
% transfrom a decimal integer to a general digit
%  Inputs: 
%   size_v: a vector consists positive integers, indicating the n-ary digits
%      e.g. size_v(i) = 3 means 3-1 = 2  is the maximum number for the i-th digits
%  Outputs:
%   v: a vector with the same length as SIVE_V consisting nonnegative
%       integers
n = length(size_v);
v = zeros(n,1);
base = prod(size_v);
for ii=n:-1:1 %  ii iterates from the high (right) digit to low (left) digit    
    base = base/size_v(ii);    
    v(ii) = floor(ind/base);
    ind = ind - v(ii)*base;    
end    
end

function flag = isIntegerVal(x)
% determine whether the value of a scalar is integer
% Inputs:
%  x: a scalar or an array;
% Outputs:
%  flag: an array with the same size as x, consisting of 1 or 0, indicating
%       whether the value of each element of x is integer;
    flag = x==round(x);
end