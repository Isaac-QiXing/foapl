function [sol,fval, exitFlag]= pu_dh(arg,X_col,y_total)
%   solve the PU learning classification model based on double hinge loss
%  
% Inputs:
%     arg: 
%        arg.cp: a positive number,  the penalty paramter of the empirical 
%           loss induced by the positive samples
%        arg.cu: a positive number,  the penalty paramter of the empirical 
%           loss induced by the unlabeled samples;
%        arg.w: a vector indicating the weight of each feature for
%           calculating the kernel matrix
%   
%   X_col:   the matrix of samples,  each column indicating a sample
%        the number of rows of X_col equal to the length of arg.w;
%
%   y_total: a column vector of labels consisting of 1 and -1; with length equal to 
%       the column number of X_col;
%       all the samples with missing labels are marked -1 label
%
% Outputs:
%   sol: the solution;
%      sol.alpha: a column vector, indicating the solutions; 
%           Note that the length(sol.alpha) == nnz(y_total==-1);
%               each element   sol.alpha(i) corresponds to i with
%               y_total(i) = -1; 
%           .b: a scalar;   
%   fval: objective funcation value at the calculated solution
%   exitFlag:
%       0: exceed the maximum iteration number
%       1: succeed to find a local minimum; 
% Reference. 
% [1]  M. C. du Plessis. Convex formulation for learning from positive and
%   unlabeled data. ICML 2015. 



% solve the programming:
%
%   min_{w}   0.5*|w|^2 
%       + Cp*\sum_{i\in Omega_p} lossP(y_i*f(x_i))
%       + Cu*\sum_{i\in Omega_u} lossU(-1*f(x_i))
%
%   where  Omega_p = {j | y_j ==+1}; Omega_u = {j | the sample x_j misses label};
%    all the samples with missing labels are labeled -1; 
%    Cp>0, Cn > 0 are two weight parameters,
%     lossP(t) =   -t   
%     lossU(t) =   max(-t, max(0,0.5-0.5*t) ) is the double hinge loss,
%     f(x) = sum_{i=1}^n alpha_i*k(x_i,x) +b,  b=0
 
% Inputs
cp = arg.cp;
cu = arg.cu;
%n_feature = size(X_col,2);
%w_feature = ones(n_feature,1);
w_feature = arg.w;

% [c1,c3,lambda_max,w_feature] = ...
%     getArgument(arg,{'c1','c3','lambda','w'});  
%   % lambda_max: maximum value of lambda at each epoch
%   
%     
% [verbose,max_ite_CCCP_batch, decrease_factor_tolFun,decrease_factor_tolX,lambda_mode,n_ite_lambda,...
%     tolFun,tolX, kernelType,r1,flag_low_rank_approx,tol_low_rank_approximation,flag_calculate_initial_point,...
%     min_tolFun,min_tolX,flag_gpu_on,display,path_user_data,maxTrainSize]= ...
%     problemArg('verbose','max_ite_CCCP_batch','decrease_factor_tolFun','decrease_factor_tolX','lambda_mode','n_ite_lambda',...
%         'tolFun', 'tolX',  'kernelType','r1','flag_low_rank_approx','tol_low_rank_approximation','flag_calculate_initial_point',...
%         'min_tolFun','min_tolX','flag_gpu_on','display','path_user_data','maxTrainSize');  

[verbose,tolFun,tolX, kernelType,r1, display]= ...
    problemArg('verbose', 'tolFun', 'tolX',  'kernelType','r1','display');  
    

n_case = length(y_total);  % number of total training samples
ind_p = y_total==1; % indices of the positive samples
ind_u = y_total==-1; % indices of the unlabeled samples

np = nnz(ind_p);
nu = nnz(ind_u);

if np+nu~=n_case
    error('The  labels should be only 1 or -1. ');
end

% parameters
arg_quad = struct('TolFun',tolFun, 'TolX',tolX);
 
%r1 = 1.0; 



lambda = 1/(nu*cu); % cu = 1/(nu*lambda)
pi_n = cp/lambda;          % cp = pi/(np*lambda) => pi/np = cp/lambda

% initialization 

x0 = zeros(2*nu,1);
 

% % calculate the kernel matrix K or its Cholesky factor matrix G
% alg_hash = 'MD5';
%   % check whether the kernel matrix or its cholesky factor matrix has
%   % existed
% h_X = hash(X_col,alg_hash);
% file_kernel_matrix_mat = [addFileSep(path_user_data) h_X '.mat'];
% flag_use_cache_kernel_matrix = 0; % whether to use the cached kernel matrix (or its factorized  matrix)
% 
% arg_chol = struct('kernelType',kernelType,'r1',r1,'tol',tol_low_rank_approximation,'w',w_feature);
% hash_arg = hash_struct(arg_chol,alg_hash);% generate hash character of the parameters for calculating the kernel matrix and its factorization
% if exist(file_kernel_matrix_mat,'file')
%     % check whether the arguments are the same with that of calculate  the
%     %   stored kernel elements        
%     data_kernel = load(file_kernel_matrix_mat);
%     
%     if isfield(data_kernel,'hash_arg')  && strcmp(data_kernel.hash_arg,hash_arg) 
%             % the hash of the current parameters for calculating the kernels (and the
%             % factorization) are the same with the stored hash
%         if flag_low_rank_approx
%             if isfield(data_kernel,'G') && ~isempty(data_kernel.G)
%                 G_total = data_kernel.G;
%                 flag_use_cache_kernel_matrix = 1; 
%                 if verbose>=1
%                     fprintf(1,'Employ the  previous calculated Cholesky factorization of the kernel matrix with size %d-by-%d.\n',...
%                         size(data_kernel.G,1),size(data_kernel.G,2));
%                 end
%             end
%         else % use the kernel matrix directly
%             if isfield(data_kernel,'K') && ~isempty(data_kernel.K)
%                 K_total = data_kernel.K;
%                 flag_use_cache_kernel_matrix = 1; 
%                 if verbose>=1
%                     fprintf(1,'Employ the  previous calculated  kernel matrix with size %d-by-%d.\n',size(data_kernel.K,1),size(data_kernel.K,2));
%                 end
%             end
%         end
%     end
% end
% 
% if flag_use_cache_kernel_matrix && verbose>=1
%     fprintf(1,'The kernel elements (or its factorization) stored in %s \n',file_kernel_matrix_mat);
% end
% 
% if ~flag_use_cache_kernel_matrix 
%         % do not use employed caching kernel matrix, then calculate the kernel matrix or its factorization.
%     if flag_low_rank_approx
%         %%arg_chol = struct('kernelType',kernelType,'r1',r1,'tol',tol_low_rank_approximation,'w',w_feature);
%         [G_total,r]= chol_kernel_matrix(X_col',arg_chol);
%         if verbose>=1
%             fprintf(1,'Finished to do Cholesky factorization of the kernel matrix.\n');
%             fprintf(1,'The rank of the Cholesky matrix: r = %d \n',r);
%         end  
%         % save the factorization
%         date_str = datestr(now,30);       
%         saveData(file_kernel_matrix_mat,'G',G_total,'r',r,'date_str',date_str,'hash_arg',hash_arg,'hash_X',h_X);
%     else
%         K_total = kernelMatrix_OnceaLine(kernelType,X_col,X_col,r1,w_feature);
%         % save the kernel matrix
%         date_str = datestr(now,30);
%         saveData(file_kernel_matrix_mat,'K',K_total, 'date_str',date_str,'hash_arg',hash_arg,'hash_X',h_X);
%     end
% end
 
 K2 = kernelMatrix_OnceaLine(kernelType,X_col(:,ind_p),X_col(:,ind_u),r1,w_feature);
 K3 = kernelMatrix_OnceaLine(kernelType,X_col(:,ind_u),X_col(:,ind_u),r1,w_feature);
    
 % solve the dual programming  
    [xk,fval,exitFlag] = solve_dual(x0,arg_quad);
    % outputs:    
    sol.alpha = xk;
    sol.b = 0; %  SVM in the primal: f(x) = \sum_{i} \alpha_i k(x_i, x);
    %%%fval_dual = - fval_k + c3*sum(y(ind_target)); 
    %fval = obj_foapl(xk);
    if verbose>0
        fprintf(1, 'fval_opt: %.3f, exitflag: %d\n',fval,exitFlag);
    end

 
    
    function [x,fval,exitflag] = solve_dual(x0,arg_quad)
        % solve the dual programming  
        % Inputs:
        %  x0: the initial point, set [] if not specified the initial
        %     point; 
        % arg_quad: optional, stucture of the parameters
        %    .TolFun:  Termination tolerance on the function value, a positive scalar.
        %           Apply for all algorithms, except active-set	
        %       For a 'trust-region-reflective' equality-constrained problem, the default value is 1e-6.
        %       For a 'trust-region-reflective' bound-constrained problem, the default value is 100*eps, about 2.2204e-14.
        %       For 'interior-point-convex', the default value is 1e-8.
        %   .TolX:     % Termination tolerance on x, a positive scalar.
        %       For 'trust-region-reflective', the default value is 100*eps, about 2.2204e-14.
        %       For 'interior-point-convex', the default value is 1e-8.
        %
        % Outputs:
        %    x: the solution
        % fval: objective function value
        % flag: 1: Function converged to the solution x.
        %   0: Number of iterations exceeded options.MaxIter.
        %  -2:   Problem is infeasible.
        %  -3:   Problem is unbounded.
  
       options = optimset('TolFun',arg_quad.TolFun, 'TolX',arg_quad.TolX,'Display',display, ...%'MaxFunEvals',max(4*l,3000),...                 
        'GradObj','on','Algorithm','interior-point',...
        'Hessian','user-supplied','SubproblemAlgorithm','cg','HessMult',@HessMultFcn, 'DerivativeCheck','off'); 
        
        nonlcon=[];
        A = [eye(nu) eye(nu)];
        b = 1/nu*ones(nu,1); % A* x <=b 
        Aeq = [];
        beq = [];
        A_v = zeros(2*nu,1); %lower bounds
        B_v = 1/nu*ones(2*nu,1); % upper bounds
          [x,fval,exitflag] =  fmincon(@fun,x0,A,b,Aeq,beq,A_v,B_v,nonlcon,options);
%         [x,fval,exitflag] =  quadprog(K,-y,A,b,Aeq,beq,A_v,B_v,x0,options); 
    end % end sub-function solve_dual 

    function [fx,gd] = fun(alpha)     
        % objective function value
        u = alpha(1:nu);
        v = alpha(nu+1:end);
        t1 = K3*u;
        t2 = K3*v; 
        
        w = zeros(2*nu,1);
        w(1:nu) = 0.25*(t1 + t2); 
        w(1+nu:end) = 0.25*t1 + t2; 
        
        z = zeros(2*nu,1);
        ones_np = ones(np,1);
        t3 =  (ones_np'*K2)';   % K2'*ones_np
        
        z(1:nu) =  -pi_n * 0.5* t3 - 0.5*lambda;
        z(1+nu:end) = -pi_n*t3;  
        
        fx = 0.5*sum(alpha.*w) + sum(z.*alpha);    
        gd = w+z;
       
    end

    function w = HessMultFcn(x,lambda,v)
    % Inputs:
    %   lambda:  the Lagrange multiplier (computed by fmincon)
    %    v:     a vector of size n-by-1. 
    % Outputs: w : the product H*v, where H is the Hessian of the Lagrangian at x,
    
        v1 = v(1:nu);
        v2 = v(nu+1:end);
        t1 = K3*v1;
        t2 = K3*v2;
        
        w = zeros(2*nu,1);
        w(1:nu) = 0.25*(t1 + t2); 
        w(1+nu:end) = 0.25*t1 + t2; 
    end
    
end
