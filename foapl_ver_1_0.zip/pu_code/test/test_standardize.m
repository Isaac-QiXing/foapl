% test_standardize
n = 5;
m = 3;
X = randi(10,n,m);
[Xp,mean_v,std_v] = standardize(X)