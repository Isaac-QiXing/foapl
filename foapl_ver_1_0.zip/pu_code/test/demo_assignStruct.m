% demo_assignStruct.m

arg = struct('n',20,'k',5);
arg_field_cell = {'k','val'};
arg_val_cell = {4,'job'};
arg2 = assignStruct(arg, arg_field_cell,arg_val_cell);


 
 