% test_pu_label.m 

classPrior = 0.4;

n = 30;
 
y = randi(2,n,1)*2-3;


[y_pu, ind_train] =  pu_label(y,classPrior);

y_pu
y
ind_train