 % test_kernelMatrix_OnceaLine
 
 k = 2;
 m = 3;
 n = 4;
 A = rand(k,m);
 B = rand(k,n);
 arg = 0;
 w = 1:k;
 kernelName = 'linear';
 H = kernelMatrix_OnceaLine(kernelName,A,B,arg,w)
 H = kernelMatrix_OnceaLine(kernelName,A,A,arg,w)