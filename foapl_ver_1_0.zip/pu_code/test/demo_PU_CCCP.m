clear

n_feature = 1; 
np = 20;
nu = 40;
n_case = np+nu;
pi = 0.5;
lambda = 0.5; %1.0;

arg.cp= 2*pi/(np*lambda);
%a positive number,  the penalty paramter of the empirical 
 %           loss induced by the positive samples
arg.cu = 1/(nu*lambda);
 %        arg.cu: a positive number,  the penalty paramter of the empirical 
%           loss induced by the unlabeled samples;
arg.w = ones(n_feature,1);
%        arg.w:



verbose = 1;
tolFun = 1E-3;
tolX = 1E-3;
kernelType = 'linear';
r1 = 1.0; % the linear kernel: k(x,x') = <x,x'> + r1
userSetting({'verbose',verbose, 'tolFun',tolFun, 'tolX',tolX, 'kernelType',kernelType,'r1',r1 });
 
flag_produce_dataset = 1; % produce the new data set
dataType = 1; 
    % 1: the unlabeled samples randomly comes from positive and negative
    % samples
    % 2: the positve samples among the unlabeled ones have different distribution 
    %   with those labeled positives 
    % 3: replace one instance with an outlier based on the dataset in Case1
    
% synthetic data
mu_p =2; 
mu_n =-2;
sigma = 1; 
pi_p = 0.5; % class prior of positive samples


fileName = sprintf('toyData_pu_type%d.mat',dataType); 

if flag_produce_dataset
    switch dataType
        case 1
            X_col = zeros(n_feature,np+nu);
            X_col(1,1:np) = sigma* randn(1,np) + mu_p;

             % generate unlabeled samples
            ind_p = rand(1,nu)> pi_p; 
                % consisting of 1 or 0, 1: a positive sample,   
            nu_p = nnz(ind_p); % number of positive samples among the unlabeled samples
            nu_n = nu- nu_p; %  number of negative samples among the unlabeled samples
            x_u = zeros(1,nu);
            x_u(ind_p) = sigma* randn(1,nu_p) + mu_p;
            x_u(~ind_p) = sigma* randn(1,nu_n) + mu_n;
            X_col(1,np+1:end) = x_u;
            %%%X_col(2,:) = 1; % append a feature with constant values 1

        case 2
            X_col = zeros(n_feature,np+nu);
            X_col(1,1:np) = sigma* randn(1,np) + mu_p;

            % generate unlabeled samples
            ind_p = rand(1,nu)> pi_p;
            % consisting of 1 or 0, 1: a positive sample,
            nu_p = nnz(ind_p); % number of positive samples among the unlabeled samples
            nu_n = nu- nu_p; %  number of negative samples among the unlabeled samples
            x_u = zeros(1,nu);
            % sample nu_p samples satisfying that x>= mu_p + 3*sigma 
            xu_p = zeros(1,nu_p); 
            ii = 1;
            while 1
                if ii>nu_p
                    break
                end
                rdn = randn(1);
                if rdn>3.0
                    xu_p(ii) = rdn;
                    ii = ii+1;
                    continue;            
                end
            end        
            %x_u(ind_p) = sigma* abs(randn(1,nu_p)) + mu_p;
            x_u(ind_p) = sigma* xu_p + mu_p;
            x_u(~ind_p) = sigma* randn(1,nu_n) + mu_n;
            X_col(1,np+1:end) = x_u;
            %%%X_col(2,:) = 1; % append a feature with constant values 1

            case 3
            X_col = zeros(n_feature,np+nu);
            X_col(1,1:np) = sigma* randn(1,np) + mu_p;
            %X_col(1,np)  =  10*sigma  + mu_p; % replace the last positive with an outlier

             % generate unlabeled samples
            ind_p = rand(1,nu)> pi_p; 
                % consisting of 1 or 0, 1: a positive sample,   
            nu_p = nnz(ind_p); % number of positive samples among the unlabeled samples
            nu_n = nu- nu_p; %  number of negative samples among the unlabeled samples
            x_u = zeros(1,nu);
            x_u(ind_p) = sigma* randn(1,nu_p) + mu_p;
            x_u(~ind_p) = sigma* randn(1,nu_n) + mu_n;
            x_u(end)  =   30*sigma  + mu_p; % replace the last positive with an outlier

            X_col(1,np+1:end) = x_u;

    end
    x_u = X_col(1,np+1:end)';
    x_p = X_col(1,1:np)';

    y_total = zeros(nu+np,1);
    y_total(1:np) = 1;
    y_total(np+1:end) = -1;
    %%%
    timestamp = datestr(now,30);
    save(fileName,'X_col','y_total','arg','np','nu','pi','lambda','kernelType','r1','timestamp')
    %%%
else
    load(fileName,'X_col','y_total');
end

 
 
%%[sol,fval, exitFlag]= pu_dh(arg,X_col,y_total);
[sol_batch,fval_batch, exitFlag_batch]= pu_CCCP_batch(arg,X_col,y_total);

alpha_v = sol_batch.alpha;
bar_x = -r1*sum(alpha_v)/dot(alpha_v,X_col);

fwritef(1, 'dataType',dataType,'%d','norm_x',norm(sol_batch.alpha),'', '',fval_batch,'','bar_x',bar_x,'');
