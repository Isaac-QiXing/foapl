%test_ramp.m

fplot(@ramp,[-4,4])