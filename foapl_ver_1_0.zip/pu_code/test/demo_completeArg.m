% demo_completeArg.m

arg = struct('n',20,'k',5);
arg_field_cell = {'k','val'};
arg_val_cell = {4,'job'};
arg2 = completeArg(arg, arg_field_cell,arg_val_cell);


mode_compulsory = 1;
arg3 = completeArg(arg, arg_field_cell,arg_val_cell,[],mode_compulsory);

mode_compulsory = 0;
arg4 = completeArg(arg, arg_field_cell,arg_val_cell,[],mode_compulsory);

fwritef(1,'arg',arg,'','arg2', arg2,'','arg3',arg3,'','arg4',arg4,'');
