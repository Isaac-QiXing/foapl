% test_crossValidate
n_total_sample = 10;
N = 9;
k = 4;

index = crossValidateIndex(n_total_sample,k);
fwritef(1,'index',index,'');

index = crossValidateIndex(n_total_sample,k,N);
fwritef(1,'index',index,'');
