%test_proj_box.m
A_v = [-1 -2, 0 1 2];
B_v = [-0.5, -1, 1, 1, 3];
alpha_v = [-0.6, -5, 2, 3, 0];
alpha_proj = proj_box(alpha_v, A_v,B_v);


alpha_proj
%   -0.6000   -2.0000    1.0000    1.0000    2.0000