function [acc,num] = foapl_accuracy(matScoreFile,matTestFile)
% calculate accuracies and count  TPs, FPs, TNs and FNs.

score_st = load(matScoreFile,'score_test');
testData_st = load(matTestFile,'y');
            
[acc,num] = accuracyIndex_0(score_st.score_test,testData_st.y);
acc.accuracy = (num.TP + num.TN)/max(num.TP+num.FP+num.TN+num.FN,1);

fprintf(1,'test accuracy: %.3f\n',acc.accuracy);
end