function   foapl_read(input,output,varargin)
% read libsvm training data and test  data of binary classification, 
%   if input.testFile is not specified, split the instances of dataFile to train set and test set
%  input: a struct of the data file and test file names
%   input.dataFile: file name (including the path)  of data samples of libsvm
%       format
%   input.testFile: optional, test file name of testing samples, default [];
%       if testFile is not provided, split the samples in dataFile to
%       training set and test set;
%       otherwise, save the samples in the  testFile  as test set
%   output: a struct of the mat file names of the data samples, with the following three fields:
%     output.matDataFile: mat data file name, containing all the training and testing samples
%     output.matTrainFile: mat train file name, containg the training samples and  labels
%     output.matTestFile: mat test file name, containing the testing samples and labels
%
%   varargin{1}: flag_standardize: Optional, 1 or 0, whether to standardize the
%          values of features before splitting; default value:
%          problemArg('flag_standardize');
%          if 1, make each column of DATA.INPUT stored in dataFile a
%              zero-mean unit-variance vector;
%
%     All the  output.matDataFile, output.matTrainFile,  and  output.matTestFile  contain the following variables:
%       X: a matrix, each row consists a record/sample;
%       y: a column vector with length as same number of rows of X,
%          consisting of the labels of the samples;
%     ind: a column vectore with same length as y, indexing the samples;
%          i.e., 
%                   X = X0(ind,:)
%          with X0 the data matrix contained in output.matDataFile named 'X';
%       
%   sizeX: a 1-by-2 vector, the size of matrix X;
%  X_feature: a string cell array, with the i-th element  the
%           feature name of the i-th column of the matrix X;  default {}


verbose = 1;

flag_standardize = [];
if nargin>2
    flag_standardize = varargin{1};
end
if isempty(flag_standardize)
    flag_standardize = 1;
end

% % % [path_str,dataset] = fileparts(dataFile);
% % % path_str =  addFileSep(path_str);
% % % matDataFile = sprintf('%s%s.mat',path_str,dataset);
% % % matTrainFile = sprintf('%s%s_train.mat',path_str,dataset);
% % % matTestFile = sprintf('%s%s_test.mat',path_str,dataset);

dataFile = input.dataFile;
testFile = input.testFile;
matDataFile  = output.matDataFile;
matTrainFile  = output.matTrainFile;
matTestFile  = output.matTestFile;

% read data from dataFile
[y, X] = libsvmread( dataFile );

if verbose>0
    fprintf('libsvm data file %s has read with X: %d-by-%d, y: %d-by-%d\n',...
        dataFile,size(X,1),size(X,2),size(y,1),size(y,2) );
end

% check and transform labels to +1 and -1
if nnz(y==1) + nnz(y==-1) < length(y)
    y_max = max(y);
    y_min = min(y);
    if nnz(y==y_max) + nnz(y==y_min) == length(y) && y_max > y_min
        fprintf(1,'The labels of data file consist of %d and %d and have been converted to -1 and 1.\n',y_min,y_max);
        y_old = y;
        y(y_old==y_max) = 1;
        y(y_old==y_min) = -1;
    else
        error('The labels should only consist of two values.');
    end
end
 
% if verbose>0
%     fwritef(1,'size_X',size(X), '%d\t');
% end

% split train and test file
if ~isempty(testFile)&&~exist(testFile,'file');
    warning('The specified file of test data  %s is not found.',testFile);
end
existLibsvmTestFile = ~isempty(testFile)&& exist(testFile,'file');

if ~existLibsvmTestFile
    % save the data to matDataFile
    data = struct('input', X, 'input_feature',[],'output',y );
    text = struct();
    
    save(matDataFile,'data','text');
    % split the train and test file
    [matTrainFile2,matTestFile2] = foapl_split(matDataFile,'flag_standardize',flag_standardize);
    % train_test_rate is set the  value of problemArg('train_test_rate')
   
    %movefile('source','destination','f')
    movefile(matTrainFile2, matTrainFile,'f');
    movefile(matTestFile2, matTestFile,'f');
     
    return
end


%  get X_train, y_train
if existLibsvmTestFile
    X_train = X;
    y_train = y;
    ind_train = 1:size(X,1);
    if flag_standardize
        [X_train, mean_v,std_v] = standardize(X_train); % make each column of X zero-mean and unit variance
    end
    % % %     else % do not exist/use libsvm test file
    % % %         data_train = load(matTrainFile,'X','y','ind');
    % % %         X_train = data_train.X;
    % % %         y_train = data_train.y;
    % % %         ind_train = data_train.ind;
    
    saveData(matTrainFile,'X',X_train,'y',y_train,...
        'sizeX',size(X_train),'ind', ind_train, 'X_feature',{});
end

% % %     % generate labels of PU-learning instances and save train data
% % %     if ~flag_classical_classification
% % %         [y_pu, ii_train] =  pu_label(y_train,classPrior);
% % %     else % classical classification
% % %         y_pu = y_train;
% % %         ii_train = 1:length(y_train);
% % %     end

% % %     saveData(matTrainFile,'X',X_train(ii_train,:),'y',y_pu,...
% % %         'sizeX',size(X_train),'ind', ind_train(ii_train), 'X_feature',{});
% % %     if verbose>0
% % %         fwritef(1,'n_pos_pu',nnz(y_pu==1),'',  'n_unlabel_pu',nnz(y_pu==-1),'');
% % %     end


% read, standarize and save test data
if existLibsvmTestFile
    [y_test, X_test] = libsvmread(testFile);
    if verbose>0
        fwritef(1,'size_X_test',size(X_test), '%d\t');
    end
    if flag_standardize
        X_test = standardize(X_test,mean_v,std_v); % standarize
    end
    n_sample_test = length(y_test);
    n_sample_train = length(y_train);
    saveData(matTestFile,'X',X_test,'y',y_test,...
        'sizeX',size(X_test),'ind',(n_sample_train+1:n_sample_train+n_sample_test)',...
        'X_feature',{});
    % save the training data and test data to a data file
    data = struct('input', [X_train; X_test], 'input_feature',[],'output',[y_train;y_test] );
    % note that the labels saved in the data file are the orginal
    % labels of positives and negatives
    text = struct();
    save(matDataFile,'data','text');
    % else if existLibsvmTestFile ==0
    %   matDataFile, matTestFile has been generated
end

end