function [trainFile,testFile] = foapl_split(dataFile,varargin)
 % split the samples into one training set and one or multiple test sets
 %
 % Inputs:
 %   dataFile: name of mat data file containing the samples;
 %   varargin{2*i-1}: a string, the argument name;
 %   varargin{2*i}: the argument value of varargin{2*i-1}; for i=1, 2, ...
 %     the optional arguments are as follows:
 %       'train_test_rate': Optional,
 %          (1) a scaler indicating the ratio of  cardinality of train set  to the cardinality of test set;
 %          (2) or a vector indicating the percentage of each divided sets
 %         default value: problemArg('train_test_rate');
 %       'flag_standardize': Optional, 1 or 0, whether to standardize the
 %          values of features before splitting; default value: 
 %          problemArg('flag_standardize');
 %          if 1, make each column of DATA.INPUT stored in dataFile a 
 %              zero-mean unit-variance vector;
 % Outputs:  
 %   trainFile: name of mat file which contains the samples for
 %      training;
 %   testFile: name of mat file which contains the samples for test;
 %      If to divide multiple test sets, then testFile is a cell array, each cell consists of a test file name  
 %      The function suppot 1000 test files at most.
 %
 %     both of trainFile and testFile(s)  contain the following variables:
 %       X: a matrix, each row consists a record/sample;
 %       y: a column vector with length as same number of rows of X,
 %          consisting of the labels of the samples;
 %     ind: a column vectore with same length as y, indexing the samples;
 %   sizeX: a 1-by-2 vector, the size of matrix X;
 %  X_feature: a string cell array, with the i-th element  the
 %           feature name of the i-th column of the matrix X; 
 
 % usage:
 %  demo1. split a train set and test set according the ratio of 2:1
 %   [trainFile,testFile] = foapl_split(dataFile, 'train_test_rate',2/1)
 %  
 %  demo2. split a train set and 2 test sets according the ratio of 3:2:1
 %   [trainFile,testFile] = foapl_split(dataFile, 'train_test_rate',[3,2,1]/6)
 
 
 
 
 % assign the arguments to a structure
arg = [];
len_arg = length(varargin); 
if len_arg>0
    arg = assignStruct('', varargin(1:2:len_arg),varargin(2:2:len_arg));
end
  % complete arguments with the default values
[train_test_rate,flag_standardize,path_foapl_data]= ...
    problemArg('train_test_rate','flag_standardize','path_foapl_data');
arg = completeArg(arg,{'train_test_rate','flag_standardize'},...
    {train_test_rate,flag_standardize});

%  assign the name of train file and test file(s)
[pathstr, name] = fileparts(dataFile);
if isempty(pathstr) % the user set the file path    
    pathstr = path_foapl_data;      
end

if length(arg.train_test_rate)<=2
    n_test = 1; % n_test: number of test files to be divided
else
    n_test = length(arg.train_test_rate)-1;
end

timeStamp = datestr(now,30);
trainFile = [addFileSep(pathstr)  name '_train_' timeStamp '.mat'];

if n_test==1
    testFile =  [addFileSep(pathstr)  name '_test_'  timeStamp '.mat'];
else %n_test>1
    testFile = cell(n_test,1);
    for ii=1:n_test
        str_id = sprintf('%03d_',ii); % support 10^3 = 1000 test files at most
        testFile{ii} =  [addFileSep(pathstr)  name '_test_' str_id timeStamp '.mat'];
    end
end

% split
split_train_test(dataFile,trainFile,testFile,arg);

end
