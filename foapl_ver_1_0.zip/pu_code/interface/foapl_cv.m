function [result_opt,par_opt] = foapl_cv(varargin)
% Inputs:
%    varargin{2*i-1}: a string, the parameter name;
%    varargin{2*i}: the parameter value of varargin{2*i-1}; for i=1, 2, ...
%    the optional arguments are as follows:
%       '-k': value of k for k-fold cross validation, default 5;
%       '-z': a positive integer,  maximum number of samples used for cross validation, default 5000;    
%       '-v':  0, 1
%        0: do not print any information to command window;       
%        1: put out progress information briefly to command window;
%
%  
%   The last one or two or three inputs
%  matTrainFile: mat train file name
%  par_search: a struct indicating the parameters to determine the numerical values by   cross validation
%      set [] to use the following default value; 
%    par_search = struct(...
%      'lambda',[   2^(-3) 2^(-6) 2^(-9) 2^(-12) ],...
%      'r1',[2^(-2) 1  2^1  2^2  2^3  2^4  2^6   2^9  2^15]);
%    Supported fields of par_search for cross validation: 
%        'lambda',     regularization weight 
%        'kernelType', kernel name, eg.  'rbf', 'linear', default value  'rbf'
%          'r1',   	   kernel parameter; 
%  bestResult: a function handle to find the best result with format
%           i_opt = bestResult(result_st)
%        with result_st a struct array with four fields .TP, .FP, .TN, .FN.
%           i_opt: an index of result_st indicating the best result  
%
% usage 1.
%    foapl_cv(matTrainFile);
%
% usage 2.
%    par_search = struct( 'lambda',[   2^(-3) 2^(-6) 2^(-9) 2^(-12) ],...
%        'r1',[2^(-2) 1  2^1  2^2  2^3  2^4  2^6   2^9  2^15]);
%    foapl_cv(matTrainFile,par_search);
%
% usage 3.
%    
%    foapl_cv(matTrainFile,par_search,@findBestResult);
%
% Outputs:
%   result_opt: the optimal reach result on validation sets
%   par_opt: a struct indicating the parameter values with optimal accuracy
 

% 0.1 get arguments
[par_new,varargin_par ] = identifyPar(varargin{:});

%%%
%   fwritef(1,'',par_new,'','',varargin_par,'');
%%%

arg = struct();
len_arg = length(par_new); 
if len_arg>0
    arg = assignStruct('', par_new(1:2:len_arg),par_new(2:2:len_arg));
end

% get  Inputs 
if isempty(varargin_par)
    error('There should be at least one input:  matDataFile.');
end
if length(varargin_par)>=1
    matTrainFile = varargin_par{1};       
end
if length(varargin_par)>=2    
    par_search = varargin_par{2};
else
    par_search =struct(...
     'lambda',[   2^(-3) 2^(-6) 2^(-9) 2^(-12) ],...
     'r1',[2^(-2) 1  2^1  2^2  2^3  2^4  2^6   2^9  2^15]);
end

h_bestResult = [];
if length(varargin_par)>=3
    h_bestResult = varargin_par{3};
end

if ~isa(h_bestResult, 'function_handle')&& length(varargin_par)>=3
    warning('The specified 3rd Input should be a function .');
end

if ~isa(h_bestResult, 'function_handle')
    h_bestResult = @findBestResult;
end


[fold_k,maxTrainSize,verbose,classPrior,solver_cv] = ...
    problemArg('fold_k','maxTrainSize_cv','verbose','classPrior','solver_cv');

arg = completeArg(arg, ...
  {'fold_k','maxTrainSize','verbose'},...
  {fold_k,maxTrainSize,verbose});  

par_alg = ... % parameters for each dataset
    struct('classPrior',  classPrior, ...           
           'lambda',     1.0,...
           'kernelType', 'rbf',... % 'linear';%
            'r1',   1.0,...
            'svm_theta_solver',  solver_cv); 
        
alg = @pu_predict;

[result_opt,par_opt]= crossValidate(alg,matTrainFile, par_alg, par_search,...
      'k',arg.fold_k,'n',arg.maxTrainSize,'bestResult',h_bestResult);
  
end
  