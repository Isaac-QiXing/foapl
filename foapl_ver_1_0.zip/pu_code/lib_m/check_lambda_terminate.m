function flag = check_lambda_terminate(alpha_v,arg,X_col,y)
% determine whether to terminate the iteration of SPL parameter lambda for 
%   the function CSVM_CCCP_online()
% Inputs:
%   alpha_v: the solution of dual CSVM, the same as the Output of CSVM_CCCP_online()
%   arg, X_col, y:  the same as the Inputs of CSVM_CCCP_online()
% Outputs:
%   flag: 0 or 1.
%       1: terminate the iteration of SPL parameter lambda
%       0: continue the iteration of SPL parameter lambda 

flag = 0;

global data_file_global train_file_global hint_file_global test_file_global data

if isempty(data)
     load(data_file_global,'data');
end

n_train =length(alpha_v);
sol.alpha = alpha_v;
sol.b=0;
sol.ind = (1:n_train)';
[kernelType, r1,fdr] = problemArg('kernelType', 'r1','fdr');

% calculate scores
argScore_hint = struct('trainFile',train_file_global,'kernelType',kernelType,...
    'r1',r1,'w',arg.w, 'testFile',hint_file_global, 'flagOutput','train_test');  

[score_train,score_hint] = calulate_score(sol,argScore_hint);

argScore_test = struct('trainFile',train_file_global,'kernelType',kernelType,...
    'r1',r1,'w',arg.w, 'testFile',test_file_global, 'flagOutput','test');  

[score_test] = calulate_score(sol,argScore_test);

% load indices
train_st = load(train_file_global,'ind');
hint_st = load(hint_file_global,'ind');
test_st = load(test_file_global,'ind');

% calculate accuracy 
indexRank = {score_train;score_hint;score_test};
digestIndex = [];
arg.fdr = fdr;
arg.index = {train_st.ind; hint_st.ind; test_st.ind}; 
[acc,num] = accuracyIndex(indexRank,data.output,digestIndex,arg);
if length(num) ==4
    fwritef(1,'fdr',arg.fdr,'%.2f',...
        'TP and FPs',[num(1).TP, num(1).FP, num(2).TP, num(2).FP, num(3).TP,num(3).FP, num(4).TP, num(4).FP],'%d\t',...
        'ratio',[(num(2).TP+num(2).FP)/(num(4).TP+num(4).FP),(num(3).TP+num(3).FP)/(num(4).TP+num(4).FP) ],'%.3f\t');    
end
    
  % calculate accuracies under other FDR levels

arg.fdr = 0.15;
[acc,num] = accuracyIndex(indexRank,data.output,digestIndex,arg);
if length(num) ==4
    fwritef(1,'fdr',arg.fdr,'%.2f',...
        'TP and FPs',[num(1).TP, num(1).FP, num(2).TP, num(2).FP, num(3).TP,num(3).FP, num(4).TP, num(4).FP],'%d\t',...
        'ratio',[(num(2).TP+num(2).FP)/(num(4).TP+num(4).FP),(num(3).TP+num(3).FP)/(num(4).TP+num(4).FP) ],'%.3f\t');    
end

arg.fdr = 0.25;
[acc,num] = accuracyIndex(indexRank,data.output,digestIndex,arg);
if length(num) ==4
    fwritef(1,'fdr',arg.fdr,'%.2f',...
        'TP and FPs',[num(1).TP, num(1).FP, num(2).TP, num(2).FP, num(3).TP,num(3).FP, num(4).TP, num(4).FP],'%d\t',...
        'ratio',[(num(2).TP+num(2).FP)/(num(4).TP+num(4).FP),(num(3).TP+num(3).FP)/(num(4).TP+num(4).FP) ],'%.3f\t');    
end


%%%%save('temp0901.mat','acc','num','indexRank','data','arg');    
end