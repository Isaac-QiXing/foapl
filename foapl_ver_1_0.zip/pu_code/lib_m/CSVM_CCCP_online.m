function [sol,ite_s]=CSVM_CCCP_online(arg,X_col,y)
%   solve the unequal cost FoApL model based on C-SVM by online CCCP (Convex-Concave Procedure);
%  
% Inputs:
%     arg: 
%        arg.c1: a positive number,  the penalty paramter of the empirical 
%           loss induced by the decoys;
%        arg.c3: a positive number,  the penalty paramter of the empirical 
%           loss induced by the targets;  
%        arg.lambda:   the weight parameter of theta;
%        arg.w: a vector indicating the weight of each feature for
%           calculating the kernel matrix
%        arg.r1: 
%        arg.verbose:
%        arg.tol_violating_pair_initial
%        arg.tol_violating_pair_min
%        arg.mu_neg
%        arg.mu_pos
%        arg.n_initial_cardinality_S
%        arg.fix_train_order   
%   
%   X_col:   the matrix of samples,  each column indicating a sample
%        the number of rows of X_col equal to the length of arg.w;
%
%   y: a column vector of labels consisting of 1 and -1; with length equal to 
%       the column number of X_col 
% Outputs:
%   sol: the solution;
%      sol.alpha: a column vector, indicating the solutions;
%           .b: a scalar; 
%           the discriminat function is determined by 
%                 f(x) = \sum_{i} \alpha_i k(x_i, x) + b;
%   ite_s: the structure of iteration charateristics, with  following fields 
%    .obj_val:  an  n_epoch-by-1-by-n_ite_lambda array, consisting of objective function values
%		with various epoches and iterated lambda values
%    .obj_val_item: an  3-by-n_epoch-by-n_ite_lambda array, consistting of the three components
%		of the objective function values  
%    .dist: an  n_epoch-by-1-by-n_ite_lambda array, consisting of the distances of the gradient
%		to the normal cone of box constraints 
%    .n_S: an  n_epoch-by-1-by-n_ite_lambda array, consisting of the number of elements in the active set S
%    .n_clean: an  n_epoch-by-1-by-n_ite_lambda array, consisting of the number of executed clean operations 
%    .n_clean_sample: an  n_epoch-by-1-by-n_ite_lambda array, consisting of the number of cleaned samples
%    .n_vary_bound: an  n_epoch-by-1-by-n_ite_lambda array, consisting of the number of varied bounds
%    .n_vary_alpha: an  n_epoch-by-1-by-n_ite_lambda array, consisting of the number that the solution is updated by REPROCESS()     
%    .n_reprocess: an  n_epoch-by-1-by-n_ite_lambda array, consisting of the number of executed reprocess operation
%    .lambda: an  n_ite_lambda-by-1 array, consisting of the values of lambda
%    .s_loss: an  n_epoch-by-1-by-n_ite_lambda array, consisting of the values of s = 1-lambda/c3
%%%    .tol_volating_pair: an  n_epoch-by-1-by-n_ite_lambda array consisting of the values of the parameter tol_volating_pair 
%    .n_S_detail:  an n_epoch-by-n_clean_operation-by-n_ite_lambda array, consisting of the values of the number
%		of active set after each clean operation
%    .n_clean_sample_detail:   an n_epoch-by-n_clean_operation-by-n_ite_lambda array, consisting of the values of the number
%		of the cleaned samples by each clean operation
%    .g_threshold_detail:  an n_epoch-by-n_clean_operation-by-n_ite_lambda array, consisting of the values of the value
%		of the parameter g_threshold after each clean opeartion

% Reference. 
% [1] S Ertekin, L Bottou, and C. L. Giles. Nonconvex online support
% vector machines. Pattern Analysis & Machine Intelligence IEEE
% Transactions on, 33(2):368�C81, 2010. 
% [2] A. L. Yuille and A Rangarajan. The concave-convex procedure. Neural
% Computation, 15(4):915�C936, 2003.


% solve the program:
%
%   min_{w}   0.5|w|^2 + c1*\sum_{i\in Omega_-} H_1(y_i*f(x_i))
%       + (c3)*\sum_{i\in Omega_+} R_s(y_i*f(x_i))
%   
%   where  Omega_+ = {j | y_j ==+1};
%    
%     H_1(t) =   max(0,1-t); 
%     R_s(t) =   min(1-s, max(0,1-t) ); 
%     f(x) = sum_{i=1}^n alpha_i*k(x_i,x) +b,  b=0
%     w = sum_i alpha_i Phi(x_i) 



% Inputs

[c1,c3,lambda_max,w_feature] = ...
    getArgument(arg,{'c1','c3','lambda','w'});  
  % lambda_max: maximum value of lambda at each epoch

    
% [verbose,max_ite_reprocess,tol_violating_pair_initial,... %%% tol_decrease_factor, 
%     n_epoch,lambda_mode,n_ite_lambda,period_clean,n_initial_cardinality_S,ratio_max_removed_non_SV, check_lambda_ite, ...
%     mu_neg, mu_pos,n_max_cache, tol_violating_pair_min,kernelType,r1,flag_gpu_on,...
%     n_max_size_S,fix_train_order,reject_nonactive_sample, mu_decoy_nonact, ...
%    mu_target_nonact_predict_correct,mu_target_nonact_predict_wrong]= ...
%     problemArg('verbose','max_ite_num_CCCP_reprocess','tol_violating_pair_initial',... %%% 'tol_decrease_factor',
%     'n_epoch','lambda_mode','n_ite_lambda','period_clean','n_initial_cardinality_S','ratio_max_removed_non_SV','check_lambda_ite',...
%     'mu_neg','mu_pos','n_max_cache','tol_violating_pair_min','kernelType','r1','flag_gpu_on',...
%     'n_max_size_S','fix_train_order','reject_nonactive_sample', 'mu_decoy_nonact', ...
%     'mu_target_nonact_predict_correct','mu_target_nonact_predict_wrong');  

[r1,verbose,tol_violating_pair_initial,tol_violating_pair_min,...
    mu_neg,mu_pos,n_initial_cardinality_S,fix_train_order] = ...
getArgument(arg,{'r1','verbose','tol_violating_pair_initial','tol_violating_pair_min',...
    'mu_neg','mu_pos','n_initial_cardinality_S','fix_train_test_set','fix_train_order'});  

[max_ite_reprocess,... 
    n_epoch,lambda_mode,n_ite_lambda,period_clean,ratio_max_removed_non_SV, check_lambda_ite, ...
     n_max_cache, kernelType, flag_gpu_on,n_max_size_S,reject_nonactive_sample, mu_decoy_nonact, ...
    mu_target_nonact_predict_correct,mu_target_nonact_predict_wrong]= ...
problemArg('max_ite_num_CCCP_reprocess',... 
    'n_epoch','lambda_mode','n_ite_lambda','period_clean','ratio_max_removed_non_SV','check_lambda_ite',...
    'n_max_cache','kernelType','flag_gpu_on', 'n_max_size_S','reject_nonactive_sample', 'mu_decoy_nonact', ...
    'mu_target_nonact_predict_correct','mu_target_nonact_predict_wrong');  
 
flag_use_gpu = flag_gpu_on && gpuDeviceCount()>0; % use gpu acceleration 
flag_single_gpuArray = 1; 
 % 1: set gpuArrays  single float type 
 % 0: set    gpuArrays  double float type 
if flag_use_gpu
    gpu_v = gpuDevice(1);
    if verbose>0
        fprintf(1,'GPU Device %i is open. It has ComputeCapability %s \n', gpu_v.Index,gpu_v.ComputeCapability);
    end      
end


  
if isempty(lambda_mode)
    lambda_mode = 1; % Fix the value of lambda 
end     
if strcmpi(lambda_mode,'SPL')
    lambda_mode = 0; % iterate lambda with Self-paced learning (SPL)
else 
    lambda_mode = 1; % default value
end
 

n_case = length(y);  % number of total training samples
i_target = find(y==1); % indices of the targets

if n_case==0
    error('No training sample.');
end

% parameters

TOL_PRECISION = 1.0E-14; % machine precision 

% set expected size of the active set S
n_ideal_cardinality_S = []; 
if isempty(n_ideal_cardinality_S)
    if n_case<=5000
        dataset_type = 'small'; % small dataset with number of elements 1-5000
        n_ideal_cardinality_S = max(ceil(n_case/4), min(100,n_case));
    elseif n_case<=15000
        dataset_type = 'normal'; % small dataset with number of elements 5001-20000
        n_ideal_cardinality_S = ceil(n_case/8);
    elseif n_case<=125000
        dataset_type = 'big'; % big dataset with number of elements 15001-125000
        n_ideal_cardinality_S = ceil(n_case/16);
    else 
        dataset_type = 'huge'; % big dataset with number of elements > 125000 
        n_ideal_cardinality_S = min(ceil(n_case/64),1E4);
    end
end

flag_small_normal_size = n_case<=15000; 
    % whether the dataset is normal size or small size 

% the maximum size of the caching matrix K0
if isempty(n_max_cache)
    n_max_cache = ceil(n_ideal_cardinality_S*6.0);
end
n_max_cache = min(n_max_cache,n_case);

n_initial_chche = min(max(ceil(n_ideal_cardinality_S*0.3),1000),n_case);
%n_step_chche = max(ceil(n_ideal_cardinality_S*0.1),1000);
n_step_chche = min(max(ceil(n_ideal_cardinality_S*0.1),300),500);

if isempty(n_initial_cardinality_S)
    n_initial_cardinality_S = ceil(n_ideal_cardinality_S/3); 
    % initial minimum number of the elements of the working set 
    %   for starting nonconvex CCCP procedure
end
n_initial_cardinality_S = min(n_initial_cardinality_S,n_case);


% % % n_max_allowed_non_SV = [];
% % % if isempty(n_max_allowed_non_SV)
% % %     n_max_allowed_non_SV = min(ceil(n_ideal_cardinality_S/4),ceil(n_case/10)); 
% % %     % maximun number of allowed non-SVs
% % %     % this setting of n_max_allowed_non_SV,  is told to the user in config.m
% % % end



if isempty(ratio_max_removed_non_SV)
    ratio_max_removed_non_SV = 0.25;
end

if isempty(mu_neg)
    mu_neg = 1.0;
end



n_max_cardinality_S = n_case; %ceil(n_case/5);
    % maximum number of the elements in the working set
    
if isempty(period_clean)
    period_clean = max(min(ceil(n_ideal_cardinality_S/4),ceil(n_case/10)),200);
         % the period (interval of number of cases) to operate clean procedure
end    
n_clean_operation = ceil(n_case/period_clean);   % number of clean operation in each epoch 

lambda_min = 0.0; % initial minimum value of lambda  
 
%lambda_increment = (lambda_max-lambda_min)/max(n_ite_lambda-1,1);
lambda_increment = (lambda_max-lambda_min)/max(n_ite_lambda,1);
% value of lambda  incresed each time
if lambda_mode==0
    lambda= lambda_increment; % start from a small value 
else % lambda_mode == 1 || lambda_mode == 'Fix'
    lambda = lambda_max;
    n_ite_lambda = 1; % ite_lambda  iterate 1 time in fix mode
end
    
% % % threshold_vary_bound = 2; %1.5;    
% % %     % if  average number of the vary bounds of targets in active set in recent iterations  <=  THIS ratio 
% % %     %   then the bounds are viewed as stable     
tol_violating_pair = tol_violating_pair_initial; % initial value of tol_violating_pair
delta_violating_pair  = min(0, (tol_violating_pair_min-tol_violating_pair_initial)/n_case);
    % variation of tol_violating_pair after training one PSM, note that it is a nonpositive value 
    
K_tt = 1; % for gaussion kernel K(x_t,x_t) always equal to 1; 
          % !! NOTE This code should be changed for other kernels used in future !! 

K = [];
ind_target =[];

K0 = zeros(n_initial_chche,n_initial_chche); % initilize caching kernel matrix
if flag_use_gpu % support gpu acceleration
    if flag_single_gpuArray    
        K0_gpu = zeros(n_initial_chche,n_initial_chche,'single','gpuArray'); % build a copy of K0 at GPU 
    else
        K0_gpu = zeros(n_initial_chche,n_initial_chche,'gpuArray'); % initilize caching kernel matrix
    end
end
IACT = []; % IACT: indices of  caching kernel elements


ite_s = struct('obj_val',zeros(n_epoch,1,n_ite_lambda), 'obj_val_item',zeros(3,n_epoch,n_ite_lambda),...
    'dist',zeros(n_epoch,1,n_ite_lambda),  'n_S',zeros(n_epoch,1,n_ite_lambda),'n_clean',zeros(n_epoch,1,n_ite_lambda),...
    'n_clean_sample',zeros(n_epoch,1,n_ite_lambda),'n_vary_bound',zeros(n_epoch,1,n_ite_lambda),'n_vary_alpha',zeros(n_epoch,1,n_ite_lambda), ...
    'n_reprocess',zeros(n_epoch,1,n_ite_lambda),...
    'lambda',zeros(n_ite_lambda,1),'s_loss',zeros(n_epoch,1,n_ite_lambda),...%%%'tol_volating_pair',zeros(n_epoch,1,n_ite_lambda),
    'n_S_detail',zeros(n_epoch,n_clean_operation,n_ite_lambda),'n_clean_sample_detail',zeros(n_epoch,n_clean_operation,n_ite_lambda),...
    'g_threshold_detail',zeros(n_epoch,n_clean_operation,n_ite_lambda));

 flag_K0_expanded = false; % whether the size of K0 is expanded
 flag_K0_cleaned = false;  % whether K0 is cleaned by CLEAN_WORKING_SET() subroutine

if verbose>=2
    % print out the value of main parameters
    fwritef(1,'c1',c1,'','c3',c3,'','lambda',lambda_max,'','lambda_mode',lambda_mode,'',...
        'n_ite_lambda_increment',n_ite_lambda,'%d', 'n_epoch',n_epoch, '%d',...
        'tol_violating_pair_initial',tol_violating_pair_initial,'',... %%%'tol_decrease_factor',tol_decrease_factor,'',
        'tol_violating_pair_min',tol_violating_pair_min,'',... %%%'n_ideal_cardinality_S',n_ideal_cardinality_S,'%d',        
        'n_initial_cardinality_S',n_initial_cardinality_S,'%d',...
        'period_clean',period_clean,'%d','ratio_max_removed_non_SV',ratio_max_removed_non_SV,'',...
        'mu_neg',mu_neg,'%.4f','mu_pos',mu_pos,'');
end
 

% ------------  CCCP procedure ---------------

    % initialization 
  
    S = zeros(n_max_cardinality_S,1);  % the working set, consisting of the indices of current active samples  
       
    i_tail = 0; % index of the current   active element in the working set vector S; 
        % e.g., i_tail = 3 indicating S(1:3) are the current working indices;
        
    alpha_act_v = zeros(n_max_cardinality_S,1);  % the variables of the dual programming
        % alpha_act_v(i): the S(i)-th coordinate of the dual solution alpha
           % i=1,...,i_tail       
    f_act_v = [];   
    g_act_v = zeros(n_max_cardinality_S,1); % the gradient vector,
           % g_v(i): the S(i)-th coordinate of the gradient vector
           % i=1,...,i_tail
           
    IACT_delta = [];        
    flag_S_initialized = 0; % 0 or 1, whether the working set finished initialization
    % lower and upper bounds for optimization variable a_v
    A0_v = (-c1)*ones(n_case,1);
    A0_v(i_target) = 0;
    B0_v = zeros(n_case,1);
    B0_v(i_target) = c3; 
    
        % lower and upper bounds for the variable alpha_v
    A_act_v = zeros(n_max_cardinality_S,1);
    B_act_v = zeros(n_max_cardinality_S,1); 
        %     A_act_v(i) <= alpah_v(S(i)) <= B_act_v(i),  for any i in S
        % i.e., A_act_v(i) is the lower bound of alpha(S(i))
        %       B_act_v(i) is the upper bound of alpha(S(i))  
    
    % calculate the value of s    
    s_loss =   1-lambda/c3; 
    
    % initialize iteration informations  
    i_reprocess_total_v = zeros(n_epoch,1); % indicating total number of reprocess operation
    n_vary_bound_v = zeros(n_epoch,1); 
   
    
    if verbose>=4
        fid = fopen([datestr(now,30), '.txt'],'w');
    end
    
% online iterations   
for ite_lambda = 1:n_ite_lambda    
    if verbose>1
         fprintf(1,'  =====   ite  %d: lambda: %.3f ===== \n',ite_lambda,lambda);
    end 
    % set iteration information
    ite_s.lambda(ite_lambda) = lambda;
    
    for i_epoch = 1:n_epoch
        if verbose>1
            fprintf(1,' epoch %d,\t lambda: %.4f\t s_loss: %.4f\t,tol_violating_pair: %.4f \n',i_epoch,lambda,s_loss,tol_violating_pair);            
        end
        % set iteration information
        ite_s.s_loss(i_epoch,1, ite_lambda) = s_loss;
% % %         ite_s.tol_violating_pair(i_epoch,1,ite_lambda) = tol_violating_pair;
        
        if fix_train_order
          % fix the  order to enter into the online learning iteration at different calls
            rng(i_epoch,'twister'); % at different epochs, the order differs
            [i_case_v] = randperm(n_case); % randomly order the samples
        else
            % make the order to enter into the online learning process different at different calls
            rng('shuffle');
            [i_case_v] = randperm(n_case);  
        end
        
        tol_violating_pair = tol_violating_pair_initial; % reset tol_violating_pair_initial 
        
        % at each new epoch, the variables alpha_v (solution), A_target_v,
        % B_target_v (bounds)  iterate continuously with the previous epoch

        i_clean_act=0; % indicating number of effective clean operation
        n_clean_total = 0; % total number of cleaned indices from the working set          
        n_vary_alpha = 0; % total number that the solution is updated by REPROCESS()
        jj = 0; % number of PSMs that has been added into the working set 
        for jj_case=1:n_case
            % pick an index i_case 
            i_case = i_case_v(jj_case); 
            
            % Step 0. Preparation.
            % Step 0.1 update tol_violating_pair       
            tol_violating_pair =   tol_violating_pair + delta_violating_pair;  
            
            % Step 0.2 continue to deal with the next PSM if the new coming sample is  predicted correct 
            if reject_nonactive_sample && i_tail > n_initial_cardinality_S
                IACT_icase = find(abs(alpha_act_v(1:i_tail))>1E-5);
                k_v = kernelMatrix_OnceaLine(kernelType,X_col(:,IACT_icase),X_col(:,i_case),r1,w_feature);
                g_icase = y(i_case) - dot(k_v,alpha_act_v(IACT_icase)); % partial derivative of objective function 
                flag_active = 1; 
                if  (y(i_case)==-1 && g_icase >= mu_decoy_nonact) || (y(i_case)==1 && g_icase <= - mu_target_nonact_predict_correct ) || ...
                (y(i_case)== 1 && g_icase >= 1-s_loss + mu_target_nonact_predict_wrong )
%                 if  (y(i_case)==-1 && g_icase >= mu_neg) || (y(i_case)==1 && g_icase <= - 8.0 ) || ...
%                     (y(i_case)== 1 && g_icase >= 1-s_loss + 1.0 )
                    flag_active = 0; % the PSM i is not active to the current discriminant function
                end
                if ~flag_active
                    continue;                
                end                               
            end
            jj = jj + 1;  % jj count the number of PSMs that has been added into the working set 
            %   Step 0.3 update the variables S, K0 ( and IACT), i_IACT_target
            %   the algorithm keep IACT exactly the same as S(1:i_tail)
            if i_epoch == 1
                flag_exist_in_working_set  = 0; 
            else 
                %%%[flag_exist_in_working_set,ind_i_case] = ismember(i_case,IACT);  % whether the new coming i_case has existed in the working set            
                [flag_exist_in_working_set] = ismember(i_case,IACT);  % whether the new coming i_case has existed in the working set            
            end
            flag_K0_expanded = false; 
            if  ~flag_exist_in_working_set
                % update the working set S
                i_tail = i_tail + 1;
                S(i_tail) = i_case; % add the new coming index to the working set
                % set  lower and upper bound for the new coming sample
                if y(i_case)==-1
                    A_act_v(i_tail) = -c1;
                    B_act_v(i_tail) = 0;
                else %y(i_case)==+1
                    A_act_v(i_tail) = 0;
                    if i_tail > n_initial_cardinality_S
                        B_act_v(i_tail) = -1;
                        % for the new coming target: set upper bound -1  to ensure that its
                        %     upper bound would be updated  (the upper bound would be updated as either 0 or c3)                         
                    else
                        B_act_v(i_tail) = c3;
                    end
                end
                % update K0 and IACT
                flag_K0_expanded = update_K0(i_case);                
            end
            
            %   Step 0.4 update i_IACT_target: indices i of IACT that y(IACT(i)) == +1            

                    % update i_IACT_target    when 
                    %   (1) the new comming PSM is a target                      
                    %   (2) OR  K0 (and IACT) is cleaned by  CLEAN_WORKING_SET() subroutine                     
         
            if  jj==1||  flag_K0_cleaned     
                % re-initiale i_IACT_target
                 i_IACT_target = find(y(IACT)==1);                 
            elseif y(i_case)==1 && ~flag_exist_in_working_set       
                    % new coming sample is a target, not in the previous working set S
                    %   moreover, S is not been cleaned 
                   i_IACT_target = [i_IACT_target; i_tail]; 
             % else y(i_case) ==-1 || flag_exist_in_working_set
             %      do not need to update i_IACT_target   
            end
            
           % Step 1. Update all the bounds A_i, B_i for the targets (y_i ==+1) in active set
           %  if i_tail>n_initial_cardinality_S && y(i_case) ==1 % the sample is a target 
            i_act_bound_change = [];
%             if  i_tail > n_initial_cardinality_S  % || ite_lambda>1 || i_epoch>1 %%% && exitFlag_process==1
            if ~flag_S_initialized && i_tail > n_initial_cardinality_S 
                 flag_S_initialized = 1; % once flag_S_initialized is set 1, it would never been set 0.
            end
            if flag_S_initialized
                %update f_act_v
                alpha2_v = zeros(size(K0,2),1); % length(alph2_v) == size(K0,2) = length(K0)
                alpha2_v(1:i_tail) = alpha_act_v(1:i_tail);  % i_tail == length(IACT)
                if flag_use_gpu
                    f_act_v = gather(K0_gpu * alpha2_v);
                else
                    if isempty(f_act_v) || flag_K0_cleaned || flag_K0_expanded || length(IACT_delta)>0.1*i_tail
                        % if the number of changed indices are more than 20%, then calculate K0*alpha2_v directly
                        f_act_v = K0*alpha2_v; % length(f_act_v) == length(K0)
                    elseif ~isempty(IACT_delta)
                        delta_f = K0(:,IACT_delta) * alpha_delta_v;
                        %IACT_delta: indices i of the column of KO
                        %  that the corresponding coordinates of    alpha(S(i))  changes
                        % alpha_delta_v: a |IACT_delta|-by-1 column vector, alpha_delta_v(i) is the updates of
                        %  the solution alpha(S(i))
                        f_act_v = f_act_v + delta_f;
                        if  ~flag_exist_in_working_set
                            % calculate the function value of the new coming PSM
                            f_act_v(i_tail) = dot(K0(:,i_tail),alpha2_v);
                            % i.e.:  f_act_v(i_tail) = dot(K0(1:i_tail,i_tail),alpha_act_v(1:i_tail));
                        end
                        
                        %%%
%                         f0_act_v =  K0*alpha2_v;
%                         if norm(f_act_v-f0_act_v,inf)>1E-5
%                             save('temp0914.mat','jj','f_act_v','f0_act_v','alpha_act_v','i_tail','delta_f','IACT_delta','alpha_delta_v','f_act_v','f0_act_v');
%                             if exist('alpha0_act_v','var')
%                                 save('temp0914.mat','alpha0_act_v','-append');
%                             end
%                             error('error to update f_act_v at the %d-th PSM.',jj);
%                         end
                        %%%                     
                        
                    else  %IACT_delta ==[],  the solution alpha is not changed
                        if  ~flag_exist_in_working_set
                            % calculate the function value of the new coming PSM
                            f_act_v(i_tail) = dot(K0(:,i_tail),alpha2_v);
                            % i.e.:  f_act_v(i_tail) = dot(K0(1:i_tail,i_tail),alpha_act_v(1:i_tail));
                        end
                    end   
                end
                        
                % update bounds of the active targets
                if  ~isempty(i_IACT_target) % number of indices stored in i_IACT_target
                    f_act_target = f_act_v(i_IACT_target); 
                    
                    % if y_i*f(x_i) < s_loss, then for i \in Omega+ 
                    %   A_v(i) = - c3; 
                    %   B_v(i) = 0; 
                    % otherwise 
                    %   A_v(i) = 0; 
                    %   B_v(i) = c3;
                    % end  
                        % the active set consisting samples of both targets (y_i=+1) and
                        % decoys (y_i=-1)

                    i_target_less_s = f_act_target < s_loss;
                    B_act_target_old = B_act_v(i_IACT_target);
                    
                    A_act_v(i_IACT_target) = -c3 * i_target_less_s;
                    B_act_v(i_IACT_target) = c3 * (~i_target_less_s); % the lower bound and upper bound is [-c3,0] or [0,c3]                        
                   
                    i_act_bound_change = i_IACT_target( B_act_target_old ~= B_act_v(i_IACT_target));                    
                        % if the upper bound changes then the lower bound
                        % changes ( expect the new coming target which upper bound is set -1 initially)
                        %i_act_target_bound_change: indices i of IACT that the bounds A(S(i)) and B(S(i)) changed     
                end
            %    else   flag_S_initialized == false: do not update f_act_v and  the  bounds  of active targets           
            end  
           % Step 1.2 update the i_act_bound_change ensuring it contains the index of  the new coming sample  
            if   ~flag_exist_in_working_set 
                if isempty(i_act_bound_change) 
                    i_act_bound_change = i_tail;
                else %  i_act_bound_change is NOT empty 
                    if y(i_case) == -1 
                        i_act_bound_change =  [i_act_bound_change; i_tail]; 
                            % the above i_act_bound_change only consists of the indices of targets that bounds changed
                    % else y(i_case) == +1:  the index of new coming target has included in i_act_bound_change
                    end
                end
            % else flag_exist_in_working_set == true: the index of the coming sample needs not to be added to  i_act_bound_change  
            end
            % Step 1.3 set the index of IACT of the new coming PSM
            if   ~flag_exist_in_working_set
                i_iact_new_psm = i_tail;
            else
                i_iact_new_psm = []; % the index of the coming PSM has existed in S
            end
            % Step 1.4   count the iteration informations
            if   ~flag_exist_in_working_set
                if length(i_act_bound_change)>1
                    n_vary_bound_v(i_epoch) =  n_vary_bound_v(i_epoch) + 1; % count the number that the bounds vary (regardless of the new coming sample)
                end
            else % flag_exist_in_working_set == true
                if ~isempty(i_act_bound_change)
                    n_vary_bound_v(i_epoch) =  n_vary_bound_v(i_epoch) + 1;
                end
            end
            
            % Step 2. Solve the dual programming
            % Step 2.1 run process
            IACT_delta = []; 
            alpha_delta_v = [];
            if  ~isempty(i_act_bound_change)
                [IACT_delta,alpha_delta_v] = process_revised(i_iact_new_psm); % reset the coordinates of the solution that the bounds changed and update the gradient vector
            end
            
            
            % Step 2.2 Run reprocess
            i_reprocess = 0;
            while 1
                [exitFlag,~,i_act_S,a_stepsize]= reprocess();
                i_reprocess = i_reprocess +1;
                
                IACT_delta = [IACT_delta; i_act_S];                
                alpha_delta_v = [alpha_delta_v; a_stepsize]; 
                if exitFlag % reaching violating pair
                    break
                end
                if i_reprocess > max_ite_reprocess
                    if verbose>=2
                        fprintf(1,'reprocess procedure terminated exceeding the max iteration number.\n');
                    end
                    break
                end
            end
            n_vary_alpha = n_vary_alpha + length(IACT_delta); 
            i_reprocess_total_v(i_epoch) = i_reprocess_total_v(i_epoch) + i_reprocess;
            
            if flag_small_normal_size && verbose>1 && (mod(jj,500)==1 || jj==n_case)
                obj_val = obj_foapl();
                fprintf(1,'%d\t   obj_val: %.2f\t n_var_bound: %d\n',jj,obj_val, n_vary_bound_v(i_epoch));
            end
            
            % Step 2.3 periodically run clean 
            if mod(jj,period_clean)==1
                [n_clean,g_threshold]= clean_working_set();  
                flag_K0_cleaned = true; % K0 and IACT is cleaned by CLEAN_WORKING_SET()
                i_clean_act = i_clean_act + 1;       
                n_clean_total = n_clean_total + n_clean;
                % set iteration inforamtion
                ite_s.n_S_detail(i_epoch,i_clean_act,ite_lambda) = i_tail;
                ite_s.n_clean_sample_detail(i_epoch,i_clean_act,ite_lambda) = n_clean; 
                ite_s.g_threshold_detail(i_epoch,i_clean_act,ite_lambda) = g_threshold; 
            else
                flag_K0_cleaned = false; 
            end

        
            % putout iteration information 
            if verbose>1 && mod(jj,period_clean)==1
                fprintf(1,'\n');                
                fwritef(1,'# working set',i_tail,'%d', 'n_act_S',nnz(abs(alpha_act_v(1:i_tail))>1.0E-8),'%d' );            
                fwritef(1,'# clean ',i_clean_act,'%d', 'n_clean',n_clean,'%d','g_threshold', g_threshold,'%.3f',...
                    '#reprocess',i_reprocess_total_v(i_epoch),'%d','n_vary_alpha',n_vary_alpha,'%d');
            end 
            if verbose>=4
                fwritef(fid, 'jj',jj,'%d','i_tail',i_tail,'%d','obj',obj_foapl(),'%.4f',...
                    'S',S(1:i_tail)','%d\t', 'i_act_bound_change',i_act_bound_change','%d\t',...
                    'alpha_act_v',alpha_act_v(1:i_tail)','%.4f\t',  'g_act_v',g_act_v(1:i_tail)','%.4f\t',...
                    'A_v',A_act_v(1:i_tail)','%.4f\t', 'B_v',B_act_v(1:i_tail)','%.4f\t'); 
            end            
        end    % end of loop all the cases
        
         if verbose>=4
                fprintf(fid,'\n\n =============================== \n\n');
         end
        
% % %         % update tol_violating_pair       
% % %         tol_violating_pair =  max(tol_violating_pair * tol_decrease_factor, tol_violating_pair_min);
        
        if verbose>=2
            fwritef(1,'# working set',nnz(S),'%d',  'i_tail',i_tail,'');            
            fwritef(1,'# clean operation',i_clean_act,'%d','# cleaned PSMs',n_clean_total,'%d', ' n_alpha_change', n_vary_alpha,'%d', ...
                'n_vary_bound_v', n_vary_bound_v,'%d', '#reprocess',i_reprocess_total_v','%d\t');
        end
        
        if verbose>=2  &&  flag_small_normal_size
            [obj_val,obj_v ]= obj_foapl();
            alpha3_v = zeros(length(y),1);
            alpha3_v(IACT) = alpha_act_v(1:i_tail);
            
            f_hat = K(:,IACT)*alpha_act_v(1:i_tail);
            
            grad = -f_hat + y; % gradient of the dual quadratic sub-problem
            % set bounds
            A_v = A0_v;
            B_v = B0_v;
            i2_target_less_s = f_hat(ind_target)<s_loss;
            A_v(ind_target) = -c3 * i2_target_less_s;
            B_v(ind_target) = c3 * (~i2_target_less_s);
            % reset the bounds of i in S
            A_v(IACT) = A_act_v(1:i_tail);
            B_v(IACT) = B_act_v(1:i_tail);
            
            [dist,d_v] = dist_normal_cone_box(grad,alpha3_v, A_v,B_v); % distance of the gradient to the Normal cone of box-constrain set
            fprintf(1,'obj_val: %.4f,\t dist_normal_cone_box: %.4f\n',obj_val,dist);
            % set iteration information
            ite_s.obj_val(i_epoch,1,ite_lambda) = obj_val;
            ite_s.obj_val_item(:,i_epoch,ite_lambda) = obj_v;
            ite_s.dist(i_epoch,1,ite_lambda) = dist;            
        end
        
        % set iteration information
        ite_s.n_S(i_epoch,1,ite_lambda) = i_tail;
        ite_s.n_clean(i_epoch,1,ite_lambda) = i_clean_act;
        ite_s.n_clean_sample(i_epoch,1,ite_lambda) = n_clean_total;
        ite_s.n_vary_bound(i_epoch,1,ite_lambda) = n_vary_bound_v(i_epoch);
        ite_s.n_vary_alpha(i_epoch,1,ite_lambda) = n_vary_alpha;        
        ite_s.n_reprocess(i_epoch,1,ite_lambda) = i_reprocess_total_v(i_epoch);
        
    end % end iterate of epoch 
    
    % stopping criteria of lambda
    if lambda_mode==0 && check_lambda_ite   % SPL mode
        alpha3_v = zeros(length(y),1);
        alpha3_v(IACT) = alpha_act_v(1:i_tail);
        if check_lambda_terminate(alpha3_v,arg,X_col,y)
            if verbose
                fprintf(1,'lambda satisfies the specifies stopping criteria and terminate at lambda = %.3f\n',lambda);
            end
            break;            
        end
        % update lambda, s_loss 
        lambda = lambda + lambda_increment;
        s_loss = 1-lambda/c3; 
    end
  
end % end iterate of lambda
    
%---------- end of the CCCP procedure --------   

    % outputs:    
    sol.alpha = zeros(n_case,1);
    sol.alpha(IACT) = alpha_act_v(1:i_tail);
    
    sol.b = 0; %  SVM in the primal: f(x) = \sum_{i} \alpha_i k(x_i, x);

    if verbose>=4
        fclose(fid);
    end

% ======    nest-in subfunctions  ==========

    function [ind_act_vary,alpha_act_vary] = process_revised(i0)
         % reset the coordinates of the solution that the bounds changed and update the gradient vector 
    % Inputs: i0: the index of S where the  the new coming sample has
    %    located; if the  coming PSM has already existed in S, then i0==[]
    %   Notice. users must ensure that i0 is included in I_ACT_BOUND_CHANGE
    % Outputs:
    %   ind_act_vary: a column vector, indices of IACT that the coordiante of solution ALPHA_ACT_V changed   
    %   alpha_act_vary: a column vector, varied values of the cooridnate of solution  ALPHA_ACT_V   
    %        i.e.,
    %       alpha_act_v(ind_act_vary)  <--  alpha_act_v(ind_act_vary) + alpha_act_vary(ind_act_vary)     
    
    
        % 1) update the gradient vector
        if  (~isempty(i0) && ~isscalar(i_act_bound_change) ) || (isempty(i0) && ~isempty(i_act_bound_change) )    % i.e., length(i_act_bound_change)>length(i0)
            g_act_v(1:i_tail) = g_act_v(1:i_tail) + K0(1:i_tail,i_act_bound_change)*alpha_act_v(i_act_bound_change);   
        end
        % 2) set the indices i of IACT that alpha_act_v(i) changes
        ind_act_vary =  i_act_bound_change(alpha_act_v(i_act_bound_change) ~= 0);
        alpha_act_vary = -alpha_act_v(ind_act_vary); 
            % alpha_act_vary  = 0 - alpha_act_v(ind_act_vary)
            
        % 3)  reset solution     
        alpha_act_v(i_act_bound_change) = 0;
                
        % 3) reset   the gradient   g_act_v(i0)
        if ~isempty(i0)
            g_act_v(i0) =  y(S(i0)) -  dot( K0(1:i_tail,i0), alpha_act_v(1:i_tail) );
        end 
    end % end function process_revised()


% Reprocess

    function [exitFlag,g_abs,i_act_S,a_stepsize] = reprocess()
        % Searches all the instances among the kernel expansion
        %  and selects the instances with the maximal gradient
        % Outputs:
        %  exitFlag: 1: exit with the violating pairs satisfies specified
        %       precision;    
        %       0: exit with updating 1 elements of solution vector a_v
        %          and the gradient vector g
        %   g_abs: max{|g_max|,|g_min|} 
        %       with g_min =  min{g_v(i) | alpha_v(i) > A_v(i), i is active index };
        %       with g_max =  max{g_v(i) | alpha_v(i) < B_v(i), i is active index };
        %   i_act_S: an integer of active index that alpha_act_v(i_act_S) is updated. it is [] if alpha_act_v is not updated
        %   a_stepsize: a scalar number that  alpha_act_v(i_act_S) changed:
        %       alpha_act_v(i_act_S) = alpha_act_v(i_act_S) + a_stepsize;
       
% % %         [g_min,i0] = min(g_act_v(1:i_tail).*(alpha_v(S(1:i_tail)) > A_act_v(1:i_tail))  );
% % %         [g_max,j0] = max(g_act_v(1:i_tail).*(alpha_v(S(1:i_tail)) < B_act_v(1:i_tail))  ); 
        i_act_S = [];
        a_stepsize = [];
        [g_min,i0] = min(g_act_v(1:i_tail).*(alpha_act_v(1:i_tail) > A_act_v(1:i_tail)) );
        [g_max,j0] = max(g_act_v(1:i_tail).*(alpha_act_v(1:i_tail) < B_act_v(1:i_tail)) );        
        g_abs = max(g_max,abs(g_min)); 
        if g_abs <= tol_violating_pair
            exitFlag = 1;
            return;
        end
        % determine the updating index t
        if g_max + g_min <0  % i.e., 0<= g_max < - g_min
            g_act = g_min;
            i_act_S = i0; % index of S satisfying   i_act == S(i_act_S) 
        else
            g_act = g_max;
            i_act_S = j0; % index of S satisfying   i_act == S(i_act_S) 
        end 
        % update solution a_v and gradient g_v
        if g_act < 0           
            a_stepsize = max(A_act_v(i_act_S)-alpha_act_v(i_act_S),g_act/K_tt);
        else % g_act >=0            
            a_stepsize = min(B_act_v(i_act_S)-alpha_act_v(i_act_S),g_act/K_tt);
        end        
        alpha_act_v(i_act_S) = alpha_act_v(i_act_S) + a_stepsize;
            % get the kernel matrix elements about sample i_act
        K_i_act = K0(1:i_tail,i_act_S);
                % K_i is a column vector with length i_tail    
        g_act_v(1:i_tail) = g_act_v(1:i_tail) - a_stepsize * K_i_act;  
            % set exit flag
        exitFlag = 0; 
    end

% Clean
    function [n_clear,g_threshold]= clean_working_set()
    % remove elements from the working set 
    % CLEAN_WORKING_SET remove certain non-support vectors
    % Outputs:
    %   n_clear: number of cleared elements from the working set
    %   g_threshold: threshold of the gradient coordinates of the non-SVs    
       
        n_clear = 0;
        g_threshold = Inf;
        % 1) find the indices in S to remove 
% % %         i_S_non_sv = find( abs(alpha_v(S(1:i_tail)))< TOL_PRECISION & ...
% % %             ( (y(S(1:i_tail))==-1 & g_act_v(1:i_tail)>=mu_neg) | (y(S(1:i_tail))==1 & g_act_v(1:i_tail)<= - mu_pos) ...
% % %              |(y(S(1:i_tail))==1 & g_act_v(1:i_tail)>=1-s_loss + mu_neg) )  ); % i.e., abs(alpha_v(S(1:i_tail)))< TOL_PRECISION : a_v(S(1:i_tail)) == 0
        i_S_non_sv = find( abs( alpha_act_v(1:i_tail) )< TOL_PRECISION & ...
            ( (y(S(1:i_tail))==-1 & g_act_v(1:i_tail)>=mu_neg) | (y(S(1:i_tail))==1 & g_act_v(1:i_tail)<= - mu_pos) ...
             |(y(S(1:i_tail))==1 & g_act_v(1:i_tail)>=1-s_loss + mu_neg) )  );
             % i.e., abs(alpha_v(S(1:i_tail)))< TOL_PRECISION : a_v(S(1:i_tail)) == 0
            % candidate indices of the working set S to remove
        n_S_non_sv = length(i_S_non_sv);    
        
        if i_tail <= n_max_size_S % number of indices of S  <= maximum allowed capacity
            if n_S_non_sv == 0 % no non-SVs to remove
                return
            end
            max_removed_non_SV = max(ceil(ratio_max_removed_non_SV * i_tail), i_tail-n_max_size_S);
            if n_S_non_sv <= max_removed_non_SV                 
                ind_IACT_clear = i_S_non_sv; % all candidate non-SVs would be cleared
                n_clear =   n_S_non_sv;  
                g_threshold = mu_neg;
            else % n_S_non_sv > max_removed_non_SV
                [~, i_i_S] = sort(abs(g_act_v(i_S_non_sv)),'descend');
                ind_IACT_clear = i_S_non_sv(i_i_S(1:max_removed_non_SV));
                    % indices of IACT (and working set S) to clear  
                n_clear =   max_removed_non_SV;  
                g_threshold =  abs(g_act_v(i_S_non_sv(i_i_S(max_removed_non_SV))));               
            end                  
        else %  i_tail > n_max_size_S:  number of indices of S exceeds the maximum allowed capacity
             if i_tail - n_S_non_sv <=n_max_size_S  
                 % remove all the indices of i_S_non_sv  
                ind_IACT_clear = i_S_non_sv;  
                n_clear =   n_S_non_sv;  
                g_threshold = mu_neg;
             elseif  nnz(abs( alpha_act_v(1:i_tail) )>= TOL_PRECISION) >  n_max_size_S 
                % the nubmer of nonzeros coordinates of alpha > maximum allowed capacity
                % remove all the indices i such that  alpha_act_v(i) == 0
                %  all the indices of nonzero coordinates of alpha are reserved
                % in this  case, the number of indices in S (after cleared) would exceed the specified maximum capacity
                ind_IACT_clear = find( abs( alpha_act_v(1:i_tail) )< TOL_PRECISION);
                    %  all the indices of nonzero coordinates of alpha are reserved                    
                n_clear =   length(ind_IACT_clear);                
                 % do not specify g_theshold 
             else % i_tail - n_S_non_sv > n_max_size_S && nnz(abs( alpha_act_v(1:i_tail) )>= TOL_PRECISION) <  n_max_size_S
                % remove all the indices of i_S_non_sv and remove certain number of remaining indices i that
                %  alpha_act_v(i)==0
                %  the number of removed of indices is  i_tail-n_max_size_S  in this case
                i_S_non_sv_2 = find( abs( alpha_act_v(1:i_tail) )< TOL_PRECISION & ...
                ( (y(S(1:i_tail))==-1 & g_act_v(1:i_tail)< mu_neg) |...
                   (y(S(1:i_tail))==1 &  g_act_v(1:i_tail)> - mu_pos & g_act_v(1:i_tail)< 1-s_loss + mu_neg)));
                  % i.e.,  i_S_non_sv_2 = setdiff(find(abs(alpha_act_v(1:i_tail) )< TOL_PRECISION, i_S_non_sv)  
                ind_IACT_clear = [i_S_non_sv; subVector(i_S_non_sv_2,i_tail-n_max_size_S-n_S_non_sv)];                    
                n_clear =   length(ind_IACT_clear);  
                % do not specify g_theshold 
            end
        end
        % 2) clean caching matrix K0
        %   the remaining indices of rows (and columns) keeps their order  unchanged
        n_K0_clear = clean_kernel_cache(ind_IACT_clear);               
     
        % 3) re-arrange the the non-zero indices of S,  
        % note that the following arrangement keeps the order of the  remaining elements of S unchanged
         
        ind_IACT_hold = 1:i_tail;
        ind_IACT_hold(ind_IACT_clear) = [];
        S(1:i_tail) = [S(ind_IACT_hold); zeros(n_clear,1)];
                
        % 4) update g_act_v, alpha_act_v
        g_act_v(1:i_tail) = [g_act_v(ind_IACT_hold); zeros(n_clear,1)];
        alpha_act_v(1:i_tail) = [alpha_act_v(ind_IACT_hold); zeros(n_clear,1)];
        
        % 5) update A_act_v, B_act_v
        A_act_v(1:i_tail) = [A_act_v(ind_IACT_hold); zeros(n_clear,1)];
        B_act_v(1:i_tail) = [B_act_v(ind_IACT_hold); zeros(n_clear,1)];
        
        % 6) update i_tail
        i_tail = i_tail - n_clear; 
        
        % 7) this step is optional to execute, check the equality of working set S and IACT
        if ~isequal(IACT,S(1:i_tail))
            error('error occurs that the working set S and   IACT are not equal.');
        end
    end

 
    function [obj_val,obj_v]= obj_foapl() 
        % calculate the objective function value of dual programming of FoApL
        %  with the PSMs contained in current working set
        
        % =========== Warning ===========
        %  This function calcualte the kernel matrix directly,
        %   hence only applied for small-size datesets
        % ====================================
        % outputs:
        %   obj_val: objective function value
        %   obj_v: a 3-by-1 vector consisting of the three parts of the
        %      objective function
        
        
        % this function is NOT necessarily required in the iteration
        % it is designed ONlY for scaning iteration progress        
  
          % calculate the kernel matrix 
        if isempty(K)  
            K = kernelMatrix_OnceaLine(kernelType,X_col,X_col,r1,w_feature);        
        end    
        if isempty(ind_target)   
            ind_target =  (y == 1);
        end
    %   min_{w}   0.5|w|^2 + c1*\sum_{i\in Omega_-} H_1(y_i*f(x_i))
    %       + (c3)*\sum_{i\in Omega_+} R_s(y_i*f(x_i))
    %   <==>  
    %   min_{alpha}   0.5<alpha,K*alpha> + c1*\sum_{i\in Omega_-} H_1(y_i*f(x_i))
    %       + (c3)*\sum_{i\in Omega_+} R_s(y_i*f(x_i))
    %   
    %   where  Omega_+ = {j | y_j ==+1};
    %    
    %     H_1(t) =   max(0,1-t); 
    %     R_s(t) =   min(1-s, max(0,1-t) ); 
    %     f(x) = sum_{i=1}^n alpha_i*k(x_i,x) +b,  b=0
    %     w = sum_i alpha_i Phi(x_i) 

            % calculate the function value f(x_i)                  
            y_hat = K(:,IACT) * alpha_act_v(1:i_tail); % y_hat = K*alpha
                    % predicted value for all the PSMs                 

            % calculate the objective function value  
            obj_v = zeros(3,1);
            obj_v(1) = 0.5*  dot(alpha_act_v(1:i_tail),y_hat(IACT)); 
            obj_v(2) =c1 * sum( max(0,1+y_hat(~ind_target)) );
            obj_v(3)= c3* sum(  min(1-s_loss, max(0,1 - y_hat(ind_target)) )  );
            obj_val = sum(obj_v);
%             obj_val = 0.5*  dot(alpha_v,y_hat)  + ...
%                     c1 * sum( max(0,1+y_hat(~ind_target)) ) + c3* sum(  min(1-s_loss, max(0,1 - y_hat(ind_target)) )  );  
                                    
    end    

    function  flag_expanded  = update_K0(i_case_v)
    % update K0 and IACT        
    % Inputs:
    %   i_case_v: a column vector consisting of the new coming samples 
    %       (users should ensure no indices in i_case_v is contained in
    %       IACT
    % Outputs:
    %   flag_expanded: TRUE:  K0 is expanded by the function
    %                           FALSE: size of K0 keeps unchanged
    % Operation:
    %   * append the new comming indices to the tail of IACT
    %   * update caching kernel matrix K0
    
        % IACT : the vector of caching indices of the samples
        % K0:����caching kernel submatrix
        %       K0(i,j) = K(IACT(i),IACT(j))
    
        if length(IACT)>=n_max_cache 
            error('size of active kernel submatrix exceeded the maximum size %d. Enlarge the parameter value ``n_max_cache'' in config.m OR by userSetting().',n_max_cache);
        end
        % 1. update IACT   
         n_act0 = length(IACT);
        IACT = [IACT; i_case_v];       
            
        % 2. update K0        
        % 2.1 expand the size of the caching matrix K0 (if necessary)                        
        n_K0 = length(K0);
        n_diff = length(i_case_v);
        flag_expanded = false;
        if n_diff + n_act0 > n_K0  
            n_expand = max(n_act0+n_diff-n_K0,n_step_chche);
            K0 = [K0 zeros(n_K0,n_expand); zeros(n_expand,n_K0+n_expand)];
            flag_expanded = true;
            if flag_use_gpu
                K0_gpu = [K0_gpu zeros(n_K0,n_expand,'like',K0_gpu); zeros(n_expand,n_K0+n_expand,'like',K0_gpu)];
            end
        end
         % 2.2 calculate the elements of the required submatrix 
        K_diff = kernelMatrix_OnceaLine(kernelType,X_col(:,IACT),X_col(:,i_case_v),r1,w_feature);    
        
        % 2.3 store the newly calculated kernel elements in K0        
        n_act1 = n_act0 + n_diff; % new length of IACT       
        K0(1:n_act1, n_act0+1: n_act1) = K_diff; 
        K0(n_act0+1:n_act1,1:n_act1) = transpose(K_diff);      
        if flag_use_gpu % update K0_gpu (in GPU) as a copy of K0
            if flag_single_gpuArray
                K0_gpu(1:n_act1, n_act0+1: n_act1) = gpuArray(single(K_diff)); 
                K0_gpu(n_act0+1:n_act1,1:n_act1) = transpose(K0_gpu(1:n_act1, n_act0+1: n_act1));
            else
                K0_gpu(1:n_act1, n_act0+1: n_act1) = gpuArray(K_diff);                 
                K0_gpu(n_act0+1:n_act1,1:n_act1) = transpose(K0_gpu(1:n_act1, n_act0+1: n_act1));
            end
        end
    end

    function n_clear_cache =  clean_kernel_cache(ind_IACT_clear)
        % clear the specified kernel elements in caches K0 and clear the vector IACT
        % Inputs        
        %   ind_IACT_clear: indices of IACT to clear
        % Outputs:
        %  n_clear_cache: cleared number of rows (and colums) of the caching matrix K0 ;
        %       n_clear_cache is equal to length(ind_IACT_clear)        
        
        n_clear_cache = length(ind_IACT_clear);
        if n_clear_cache==0
            return
        end        
        n_iact = length(IACT);
        if n_clear_cache >= n_iact % all the elements of K would be cleared
            K0 = zeros(size(K0));
            IACT = [];
            if flag_use_gpu
                K0_gpu = zeros(size(K0_gpu),'like',K0_gpu);
            end
            return
        end                       
        % 1. update K0 
        iact_clear = false(n_iact,1);
        iact_clear(ind_IACT_clear) = true;   % iact_clear: a vector of logicals, lic(i)==true:  i-th column and row of K0 would be removed
        i_act_K0_hold = ~iact_clear; 
            % indices of columns (and rows) of K0 which should be reserved 

        n_hold = n_iact-n_clear_cache;         
        K0(1:n_hold,1:n_hold) = K0(i_act_K0_hold,i_act_K0_hold);
        K0(1:n_iact, n_hold+1:n_iact) = 0;
        K0(n_hold+1:n_iact,1:n_hold) = 0; 
        if flag_use_gpu % update K0_gpu 
            K0_gpu(1:n_hold,1:n_hold) = K0_gpu(i_act_K0_hold,i_act_K0_hold);
            K0_gpu(1:n_iact, n_hold+1:n_iact) = 0;
            K0_gpu(n_hold+1:n_iact,1:n_hold) = 0;             
        end
        
        % 2. update  IACT
        IACT = IACT(i_act_K0_hold);
    end

end % end of the function CSVM_CCCP_online



