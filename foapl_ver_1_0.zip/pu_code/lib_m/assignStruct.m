function varargout = assignStruct(structName, arg_field_cell,varargin)
%#function exist isfield
 % assign  variables to fields of a struct
 % Inputs: 
 %   structName: the struct variable name
 %   arg_field_cell: cell array of the fieldnames to assign;
 %   varargin{1}: Optional, 
 %      1) if a string: the name of the struct in the caller for assigning;
 %      2) if a cell vector or numeric vector with the same length as
 %          arg_field_cell, then varargin{1} consists of the values of each
 %          fields.   
 %      3) if a struct then varargin{1} contain fields, some with which
 %          located in string cell array  arg_field_cell  for assigning
 %      4) if not set or set empty: assign values of variables in the caller 
 %          to the fields of the struct;
 %        In  case 2) and 3), the input variable structName is not effective;
 %   varargin{2}: Optional,
 %      the default values for missing fields; only effective for the case
 %      2) and 3); for case 1) and 4) the missing fields are set empty [];
 % Outputs:
 %   varargin{1}: if varargin{1} is the case 2), 3) listed above, putout the
 %     structure variable; otherwise, no output variables
 %
if nargin>=3
    var_origin = varargin{1};
else
    var_origin = [];
end
if nargin>=4
    defaultVal = varargin{2};
else
    defaultVal = [];
end

if isempty(var_origin) % case 4)
    for ii=1:length(arg_field_cell)
        fieldName = arg_field_cell{ii};          
        if evalin('caller',sprintf('exist(''%s'',''var'')',fieldName))
            evalin('caller',sprintf('%s.%s = %s;',structName,fieldName,fieldName));
        else
            evalin('caller',sprintf('%s.%s =[];',structName,fieldName));
        end
    end
elseif ischar(var_origin)&&~iscell(var_origin) % case 1)
    for ii=1:length(arg_field_cell)
        fieldName = arg_field_cell{ii};          
        if evalin('caller',sprintf('isfield(%s,''%s'')',var_origin,fieldName))
            evalin('caller',sprintf('%s.%s = %s.%s;',structName,fieldName,var_origin,fieldName));
        else
            evalin('caller',sprintf('%s.%s =[];',structName,fieldName));
        end
    end
elseif isstruct(var_origin) && isscalar(var_origin) % case 3)
    for ii=1:length(arg_field_cell)        
        fieldName = arg_field_cell{ii};          
        if isfield(var_origin,fieldName)            
            var_struct.(fieldName) = var_origin.(fieldName);            
        else
            var_struct.(fieldName) =defaultVal;
        end
    end
    varargout{1} = var_struct;
elseif iscell(var_origin) || isnumeric(var_origin) 
    % var_origin is a cell or numeric vector; % case 2)
    len_var_origin = length(var_origin);     
    flag_origin_cell =iscell(var_origin);        
    for ii=1:length(arg_field_cell)
        fieldName = arg_field_cell{ii};          
        if ii<=len_var_origin
            if flag_origin_cell
                var_struct.(fieldName) = var_origin{ii};
            else
                var_struct.(fieldName) = var_origin(ii);
            end
        else
            var_struct.(fieldName) =defaultVal;
        end
    end
    varargout{1} = var_struct;
end

end