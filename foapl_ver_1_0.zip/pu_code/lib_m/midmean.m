function s = midmean(A,ind,dim)
% calculate the mean of the elements  of a vector in the median
% Inputs:
%  A: a vector or matrix;
%  ind: a vector with 2 elements, 
%       exclude the ind(1) smallest elemnts and ind(2) largest elements
%       before calculating the mean.
%  dim: Optional, operate along the DIM-th dimension, default 1 (along rows);
%       
% Outputs: 
%        operate along the dimension dim;
%           the first dimension is row, the 2nd dimension is column;
%         1) if dim = 1:   s is a row vector with the length the same as the 
%         column number of A;  s(i) is the midmean of the i-th column of A;
%         2) if dim = 2:   s is a column vector with the length the same as
%         the row number of A;  s(i) is the midmean of the i-th row of A;
%           

s = [];
if nargin<=2
    dim = 1;
end
sizeA = size(A);

% whether just need to execute the normal mean operation
flag_normal_mean = length(A)==1 || sizeA(dim)==1 ...
    || max(ind)<1;
    % 1) A is a number or 2) A is a matrix, sizeA(dim) ==1
    % 3) ind(1) ==0, ind(2) == 0;
if flag_normal_mean
    s = mean(A,dim);
    return;
end
    
if isvector(A)
    s = midmean0(A);
elseif length(size(A))==2
    
    if dim==1
        s = zeros(1,sizeA(2));
        for ii=1:sizeA(2)
            s(ii) = midmean0(A(:,ii));
        end
    else % dim==2
        s = zeros(sizeA(1),1);
        for ii=1:sizeA(1)
            s(ii) = midmean0(A(ii,:));
        end
    end
end


    function s0=midmean0(v)
        len_v = length(v);
        ind(1) = min(ind(1),len_v-1);
        ind(2) = min(ind(2),len_v-ind(1)-1);
        v = sort(v,'ascend');
        s0 = mean(v(ind(1)+1:len_v-ind(2)));
    end

end



