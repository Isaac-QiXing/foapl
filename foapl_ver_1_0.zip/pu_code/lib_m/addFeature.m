function addFeature(dataFile_standard,dataFile,varargin)
% calculate pre-defined feature values, add to the data.input and X
%   after standrization, which are stored in dataFile_standard, save the
%   new data to the file dataFile; update data.input_feature;
% varargin{1}: Optional, 1 or 0, indicate whether add the feature values
%   to matrix X and saved in the new file, default 1;
% varargin{2}: Optional, a struct containing the following items:
%   .flag_enz: 1 or 0, indicating whether employ the feature enzN and enzC;
%      default 1;
%   .flag_numProt: 1 or 0, indicating whether employ the feature numProt; 
%      default 1;
% The calculated features to train the model are as follows (append the
% values of the features (if set in  FEATURE_CALCULATE_NUMERIC and
%  FEATURE_CALCULATE_NUMERIC_REMAIN of problemArg() ) to the DATA.INPUT):  
%   peptide_len: length of the peptide
%   numProt: number of the times the matched protein matches other PSMs
%   enzN: boolean. Indicate whether the peptide preceded by a tryptic
%           site.
%   enzC: boolean. Indicate whether the peptide has a tryptic C-terminus.
%   xcorrR: xcorrR = deltacn/xcorr


if nargin>2
    flag_add2X = varargin{1};
else
    flag_add2X = 1;
end

if nargin>3
    arg = varargin{2};
else
    arg = struct();
end
arg = completeArg(arg,{'flag_enz','flag_numProt'}, {1,1});

if flag_add2X
    load(dataFile_standard,'X','text','data');
else
    load(dataFile_standard,'text','data');
end

    function addColumn2X(id_v)
        if flag_add2X
            X(:,id_v) = standardize(data.input(:,id_v));
                % standardize(): make zero-mean unit variance
        end
    end

[ feature_c,               feature_remain,...
  feature_name_peptide,    feature_name_protein,...
  feature_name_xcorr,      feature_name_deltacn,...
  feature_name_peptide_len,feature_name_numProt,...
  feature_name_enzN,       feature_name_enzC,...
  feature_name_xcorrR,     feature_name_digest_type]...
  = problemArg('feature_calculate_numeric','feature_calculate_numeric_remain',...
        'feature_name_peptide','feature_name_protein',...
        'feature_name_xcorr', 'feature_name_deltacn',...
        'feature_name_peptide_len','feature_name_numProt',...
        'feature_name_enzN', 'feature_name_enzC',...
        'feature_name_xcorrR','feature_name_digest_type');
feature_c = [feature_c feature_remain];


flag_peptide = isfield(text,feature_name_peptide) ...
         && ~isempty( text.(feature_name_peptide) );
     % whether text.(feature_name_peptide)  is empty
     
[flag_xcorr id_xcorr] = ismember(feature_name_xcorr,data.input_feature);
[flag_deltacn id_deltacn] = ismember(feature_name_deltacn,data.input_feature); 
% whether data.input contains xcorr and deltacn and their indices;

% whether to add the featue peptide_len
flag_pep_len = ismember(feature_name_peptide_len,feature_c) ...
    && flag_peptide;

% whether to add the feature numProt
flag_numProt =  arg.flag_numProt...
    && ismember(feature_name_numProt,feature_c) ...
    && isfield(text,feature_name_protein) ...
    && ~isempty(text.(feature_name_protein)) ;

% whether to add the feature enzN, enzC
flag_enzN = arg.flag_enz && ismember(feature_name_enzN,feature_c)&& flag_peptide;
     
flag_enzC = arg.flag_enz && ismember(feature_name_enzC,feature_c)&& flag_peptide;

% whether to add the feature xcorrR
flag_xcorrR = ismember(feature_name_xcorrR,feature_c)...
             && flag_xcorr && flag_deltacn;
     
flag_add_v = [flag_pep_len flag_numProt flag_enzN flag_enzC flag_xcorrR];
[n_row_input n_col_input] = size(data.input);
ind_add_v = cumsum(flag_add_v);
ind_add_v = n_col_input + ind_add_v;
feature_add_c =  {feature_name_peptide_len; feature_name_numProt;...
                  feature_name_enzN;        feature_name_enzC;...
                  feature_name_xcorrR}; 
              % feature names to be added
              %   feature_name_digest_type is added (if required) to DATA,
              %   not to matrix DATA.INPUT

n_add_col = nnz(flag_add_v);   % number of features(columns) to add

if n_add_col==0 % no features is required to be added    
    if ~exist(dataFile,'file')
        copyfile(dataFile_standard,dataFile);
    end
    return
end


% allocate the space of matrix data.input and X for the new columns
data.input(:,n_col_input+1: n_col_input + n_add_col) = zeros(n_row_input,n_add_col);
if flag_add2X
    X(:,n_col_input+1: n_col_input + n_add_col) = zeros(n_row_input,n_add_col);
end

% add the feature: peptide_len
if flag_pep_len
    id =  ind_add_v(1);
    data.input(:,id) = peptide_length(text.(feature_name_peptide));
    addColumn2X(id);    
end

% add the feature numProt: number of the times the matched protein
%   matches other PSMs
if flag_numProt
    id =  ind_add_v(2);
    %if verLessThan('matlab','7.10')
        [pro_u,m_pro,n_pro] = unique(text.(feature_name_protein));
    %else
     %   [pro_u,~,n] = unique(text.(feature_name_protein));
    %end
    p_num = falltoBags(n_pro,(1:length(pro_u))');    
    data.input(:,id) = p_num(n_pro)-1;  % -1: do not count the match itself
    addColumn2X(id);
    clear('p_num','pro_u','m_pro','n_pro');
end

% add the feature enzN and(or) enzC.
% Note that ``enz'' contains values of two featues, i.e.,
%  it corresponds to two columns of the data matrix.
if flag_enzN || flag_enzC
    if flag_enzN && flag_enzC          
        enz_id =  ind_add_v(3:4);
        data.input(:,enz_id) = calculate_enzNC(text.(feature_name_peptide));                 
        addColumn2X(enz_id);  
    else
        enz = calculate_enzNC(text.(feature_name_peptide));
        if flag_enzN
            enz_id =  ind_add_v(3);
            data.input(:,enz_id) = enz(:,1);            
            addColumn2X(enz_id);
        else % flag_enzC ==1            
            enz_id =  ind_add_v(4);
            data.input(:,enz_id) = enz(:,2);            
            addColumn2X(enz_id);
        end
        clear('enz');
    end
end

% add the feature xcorrR.
    %  xcorrR = deltacn/xcorr
if flag_xcorrR    
    id =  ind_add_v(5);
    data.input(:,id) = ...
        data.input(:,id_deltacn)./(data.input(:,id_xcorr)+~data.input(:,id_xcorr));    
    addColumn2X(id);
end

% add the values of feature digest_type as a field of structure DATA    
if ismember(feature_name_digest_type,feature_c)    
    if flag_peptide
        data.(feature_name_digest_type) = calculate_peptide_type(text.(feature_name_peptide));
    else
        data.(feature_name_digest_type) = [];
    end
end

% update data.input_feature              
data.input_feature = [columnVec(data.input_feature); feature_add_c(flag_add_v)];
  % a column string cell array

% save the datas to a new file: dataFile
if ~exist(dataFile,'file')
    copyfile(dataFile_standard,dataFile);
end
if flag_add2X
    save(dataFile,'X','data','-append');
else
    save(dataFile,'data','-append');
end

end
