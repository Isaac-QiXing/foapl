function dataTransformation(dataFile_standard, dataFile)
% transform the data stored in dataFile_standard

load(dataFile_standard,'X');

% scale the values of certain features of the data matrix X
flag_transform = problemArg('flag_transform');
% if flag_transform
%     [weight_xcorr,weight_deltacn,weight_digest] = ...
%         problemArg('weight_xcorr','weight_deltacn','weight_digest');
%     weight_v = [weight_xcorr,weight_deltacn,weight_digest];
%     X(:,[1,2,6]) = X(:,[1,2,6])*sparse(1:3,1:3,weight_v);
% end

if flag_transform
    weight_v = problemArg('feature_weight_numeric');
    len_feature = length(weight_v);
    if len_feature~=size(X,2)
        warning('The column number of X do not equal the length of feature_weight_numeric.');
    end
    X(:,1:len_feature) = X(:,1:len_feature)*sparse(1:len_feature,1:len_feature,weight_v);
end

% add new features: the distance to the decoys
% ......

% save the datas to a new file: dataFile
if ~exist(dataFile,'file')
    copyfile(dataFile_standard,dataFile);
end
save(dataFile,'X','-append');

end