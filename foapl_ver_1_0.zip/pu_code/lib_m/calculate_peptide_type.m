function [flag_peptide,varargout] = calculate_peptide_type(peptide_cell)
% identify the peptide type:  full, half and none digested
% Input:
%  peptide_cell: peptide cell array, e.g. {'A.KAGR.I','K.KGAPGP.N'};
% Output:
%  flag_peptide: a column vector with the same length as peptide_cell, 
%   containing the flag (0, 1 or 2) of the given peptides, 
%   0: none-digested, 1: half-digested, 2: full-digested
%  varargout{1}:  num_v,  a 3*1 array containing the number of full
%       digested, half digested,  none digested peptide;

% identify the peptide type
flag_peptide = columnVec(cellfun(@digested_type,peptide_cell,'UniformOutput',true));
if nargout >1
    % calculate the number of full, half and zero digested peptide
    num_v = zeros(3,1);
    num_v(1) = nnz(flag_peptide==2);
    num_v(2) = nnz(flag_peptide==1);
    num_v(3) = nnz(flag_peptide==0);
    varargout{1} = num_v;
end