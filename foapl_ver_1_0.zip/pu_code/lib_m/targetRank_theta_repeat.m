function [model] = targetRank_theta_repeat(argData,argAlg)
% rank targets by viewing the weights theta as variables;
%   repeat several times to calculate average score as the last score;
% Inputs 
%  argData: the argument structure about data, see targetRank_basic_theta for
%    detail;
%  argAlg: the argument structure about algorithm; see targetRank_basic_theta
%    for detail;
%     besides, argAlg contain the fields:
%     .num_submodel: an integer indicating the number of submodels;  
%     .maxTrainSize: maximum number of samples in train set;
% Outputs
%   model: a structure indicating the model
%     .alpha: a matrix, with each column consisting the coefficients alpha 
%           of a sub-model;
%           note that the discriminant function:
%                 f(x) = \sum_{i} \alpha_i k(x_i, x) + b;
%     .ind: a matrix with the same size as alpha_v, each column consisting
%           the indices of the samples employed for training a sub-model;
%     .b:  a column vector with the length equal the number of sub-models;
%          consisting the calculated intersepts of the discriminant
%          function; 


% arguments
[dataFile] = ...
    getArgument(argData,{'dataFile'});
[maxTrainSize,num_submodel] = getArgument(argAlg,{'maxTrainSize','num_submodel'});
[verbose, decoy_rate] = problemArg('verbose','decoy_rate');

% load data
load(dataFile,'sizeX');    
n = sizeX(1);
if verbose >=3
    fprintf('num of samples for training: %d \n',n);
end

% n less than the given training size
model = struct('alpha',[],'ind',[],'b',[]);
if n<=maxTrainSize   
    [model0] = targetRank_basic_theta(argData,argAlg);
    model.ind = (1:n)';
    model.alpha = model0.alpha;
    model.b = model0.b;
    return
end

% for  problem with the training samples greater than the given maximum
% train size 

% determine the basic number of decoys and targets in the basic model
file_submodel = sprintf('./omega_a_%s_temp.mat',datestr(now,30));
     % files to store the samples for training a sub-model;       
argSubmodel = struct('dataFile',file_submodel);
     
if verbose ==1
        printProgress(0);
end
% repeat
for k = 1:num_submodel
    % sample a given number of samples randomly
    ind = sampleData(dataFile,[],[],file_submodel,maxTrainSize,decoy_rate);
    
    tStart=tic; 
        [model0] = targetRank_basic_theta(argSubmodel,argAlg);
	t = toc(tStart);
    if k==1
        % initialize the model structure
        num_sample = length(model0.alpha);     
        model = struct('alpha',zeros(num_sample,num_submodel),...
            'ind',zeros(num_sample,num_submodel),'b',zeros(num_submodel,1));
    end    
    model.alpha(:,k) = model0.alpha;
    model.ind(:,k) = ind;
    model.b(k) = model0.b;
    if verbose ==1
        printProgress(1,num_submodel);
    elseif verbose>=2
        fprintf('\t%d-th submodel. Elapsed time: %.2fs.\n',k,t);
    end  
end

 
% delete temporary files
delete(file_submodel);
end
