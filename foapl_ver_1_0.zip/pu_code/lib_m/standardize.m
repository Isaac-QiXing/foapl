function [Xp,varargout] = standardize(X,varargin)
% make each column of X zero-mean and unit-variance
% Inputs:
% X: a data matrix with each column a feature
% varargin{1}:   a column vector of length d, consisting of the specified mean value of each feature
% varargin{2}:  a column vector of length d, consisting of the specified std (standard variation) value of each feature
% Outputs:
% Xp: the  standardized matrix with same size as X
% varargout{1}: a column vector of length d, consisting of  mean value of each feature
% varargout{2}: a column vector of length d, consisting of std value of each feature
%   with d the number of features
%   if varargin{1}, varargin{2} is specified, then

% usage :
%   [Xp] = standardize(X);
%   [Xp,mean_v,std_v] = standardize(X);
%   [Xp] = standardize(X,mean_v,std_v);


d = size(X,2);
Xp = zeros(size(X));

if nargin>1
    if nargin<3
        error('The mean value MEAN_V and std value STD_V should be specified at the same time.');
    end
    mean_v = varargin{1};
    std_v = varargin{2};
    if length(mean_v)~= d
        error('The specified mean value MEAN_V should have the length == # features  ');
    end
    if  length(std_v)~= d
        error('The specified mean value STD_V should have the length == # features  ');
    end
else
    mean_v = mean(X,1)';
    std_v = std(X,1)';
end



for i=1:d
    %%%std_i = std(X(:,i));
    %%% Xp(:,i)=(X(:,i)-mean(X(:,i)))/(std_i+~std_i);    % std_i+~std_i: deal with the case that  that std_i == 0
    Xp(:,i)=(X(:,i)-mean_v(i) )/(std_v(i)+~std_v(i));    % std_i+~std_i: deal with the case that  that std_i == 0
end

if nargout>1
    varargout{1} = mean_v;
    varargout{2} = std_v;
end

end
