function [sol]=primal_SVM_theta(arg,varargin)
%   solve the modified primal SVM model to get the optimal 
%     discriminant function and theta;
%  
% Inputs:
%     arg: 
%        arg.c1:   structral parameter of SVM, a positive scalar,            
%        arg.c2:   the weight parameter of theta, default value: c1;
%           c2 should located in (0, c1);
%        arg.GK: Optional, 'K', or 'G', indicate varargin{1} is the kernel
%           matrix K, or its low rank approximation by Cholesky
%           factorization G: 
%                       K  =  G * G'
%           where G is n-by-r matrix, with r<<n.
%           default value of arg.KG is 'K'.
%        arg.theta_target: Optional, a column vector with the same length
%           as nnz(y==1), indicating the initial value of the targets;
%        arg.tolFun_foapl: tolerance of iterated function values
%   varargin{1}: 
%       the kernel matrix K, a positive semi-definite matrix;   
%     or 
%       its Cholesky factorization matrix G (indicated by arg.GK)
%   varargin{2}: a column vector y, containing the with the
%     labels of the samples, with the same length as K;

%   
% Outputs:
%   sol: the solution;
%      sol.theta_index: a column vector consisting the indices of the
%        nonzero weights of the targets;
%      sol.theta: the nonzero weights of the targets;
%        i.e. sol.theta_index(i) = 3;
%             sol.theta(i) = 1.0; means that the 3rd sample (corresponding
%             y(3) )  is target (i.e. y(3)==1), and its weights is solved
%             1.0;
%      sol.alpha, .b:  the discriminat function:
%                 f(x) = \sum_{i} \alpha_i k(x_i, x) + b;
%

% Reference. sovle a SVM in the primal:
% [1] O. Chapelle. Training a Support Vector Machine in the primal. Neural
% Computaition. 19(5):1155--1178, 2007.


% solve the program:
%
%   min_{theta, beta}  <beta, K*beta> + c1*\sum_{i=1}^{l} theta_i * L(y_i,x_i)
%       - (c2) \sum_{i\in Omega_+} theta_i
%   s.t.          0<= theta_i <= 1, i in Omega_+
%   where  Omega_+ = {j | y_j ==+1}; set theta_i=1, for all i in Omega_{-},
%     L(y_i,x_i) = { max(0,1-y_i*K_i'*beta) }^2

% Inputs

% % % [c1 c2 theta_target GK_str] = ...
% % %     getArgument(arg,{'c1','c2','theta_target','GK'});
% % %   % note that c1, c2 is required to be set by the user
% % % 
% % % [verbose,max_ite,tolFun]= problemArg('verbose','max_ite_num_foapl','tolFun_foapl');  
  
[c1,c2, theta_target, GK_str,tolFun] = ...
    getArgument(arg,{'c1','c2','theta_target','GK','tolFun_foapl'});
  % note that c1, c2 is required to be set by the user

[max_ite]= problemArg('max_ite_num_foapl');  

if  isempty(GK_str) 
    GK_str = 'K';
end
flag_K = strcmpi(GK_str,'K'); % 1: K, 0: G
  

if flag_K
    K = varargin{1};
else
    G = varargin{1};
end
y = varargin{2};


if ~flag_K
    G_t = G';  % adjoint matrix of G;
end

l = length(y);  
i_target = find(y==1); % indices of the targets
n_target = length(i_target); % number of the targets

  % objective function
    function [fx gd ] = fun(x)
        x = columnVec(x); % ensure that x is a column vector
        beta1 = x(1:l);
        theta1 = x(l+1:l+n_target); % the weights of the targets
        theta_total = ones(l,1);
        theta_total(i_target) = theta1;        
        % function value
        if flag_K
            z = K*beta1;
        else
            z = G*(G_t*beta1);
        end
        sv = find(1- y.*z>0); % sv: indices of support vectors          
        
        %nnz(sv)
        %sum(theta_total.*max(0,1-y.*z).^2)==sum(theta_total(sv).*max(0,1-y(sv).*z(sv)).^2)        
        
        fx = sum(beta1.*z) + c1*sum(theta_total.*max(0,1-y.*z).^2) ...
            - c2*sum(theta1);        
        % the gradient        
        if flag_K
            gd = [2*(z +c1*(K(:,sv)*(theta_total(sv).*(z(sv)-y(sv)))) ); % partial differential about beta;
                  c1*max(0,1-y(i_target).*z(i_target)).^2 - c2];
                               % partial differential about theta    
        else
            gd = [2*(z +G*(G_t(:,sv)*(theta_total(sv).*(z(sv)-y(sv)))*c1 )); 
                  c1*max(0,1-y(i_target).*z(i_target)).^2 - c2];                               
        end
    end 

    function w = HessMultFcn(x,lambda,v)
        % the Hession matrix at x multiply a vector v
        %              w = H*v,
        % where H is the Hessian at of the Lagrange function at x,
        %   lambda is the Lagrange multiplier (computed by fmincon), 
        %   and v is a vector. 
        % Note that  the syntax for the trust-region-reflective algorithm
        %    does not involve lambda: w = HessMultFcn(H,v)
        
        beta1 = x(1:l);
        theta1 = x(l+1:l+n_target);        
        beta2 = v(1:l);
        theta2 = v(l+1:l+n_target);
        if flag_K
            z1 = K*beta1;
        else
            z1 = G*(G_t*beta1);
        end
        sv = find(1-y.*z1>0); % sv: indices of support vectors        
        u_target = ismember(i_target,sv); 
            % u_target(i) = 1, if i_target(i) is support vector;
            %               0, otherwise
        [u_sv id_u_sv]= ismember(sv,i_target);
            % u_sv(i) = 1, if sv(i) is a target sample;
            %           0, otherwise;
        theta_sv = ones(length(sv),1);
        theta_sv(u_sv) = theta1(id_u_sv(u_sv));
            % theta_sv(i) = 1,              if sv(i) is a decoy;
            %               theta_target(j) if sv(i) is a target,
            %                                  where  i_target(j) = sv(i)                  
   
    %  1) calculate w11 := H_{beta,beta}*beta2, H_{beta,beta} denotes the
    %    second order gradient of objective function f to the first
    %    argument    
        if flag_K
            z2 = K*beta2;
        else
            z2 = G*(G_t*beta2);
        end
        if ~isempty(sv)
            if flag_K
                %w11 = 2*(z2+c1*K(:,sv)*(theta_sv.*z2(sv))); 
                w11 = 2*(z2+K(:,sv)*(theta_sv.*z2(sv))*c1); 
            else
                w11 = 2*(z2+G*(G_t(:,sv)*(theta_sv.*z2(sv))*c1)); 
            end
        else
            w11 = 2*z2;
        end
    %  2) calculate w12 := H_{beta,theta}*theta2, H_{beta,theta} denotes the
    %    second order gradient of objective function f first to the 2nd
    %    argument, theta, then to the first one, beta;
        z12 = z1 - y; % K*beta1-y
        if nnz(u_target)>0 % note that u_target consisting of 1, 0.            
            i_u_target = i_target(u_target); 
            if flag_K
                w12 = 2*c1* (K(:,i_u_target) * (z12(i_u_target).* theta2(u_target)));
            else
                w12 = 2*c1* (G* (G_t(:,i_u_target) * (z12(i_u_target).* theta2(u_target))));
            end
        else
            w12 = zeros(l,1);
        end
    % 3) calculate w21:= H_{theta,beta}*beta2
        w21 =   2*c1* u_target.*z12(i_target).*z2(i_target);
    % 4) w22:= H_{theta,theta}*theta2 =0, because   H_{theta,theta} = 0
        w = [w11+w12; w21];  
    end % end the function HessMultFcn()
    

    % initial point
    if isempty(theta_target)
        theta_target = 0.1*ones(n_target,1);        
    end
    x0  = [zeros(l,1);
           theta_target];
  
    A = [];
    b = [];
    Aeq = []; 
    beq = []; 
    lb = [-Inf*ones(l,1);
           zeros(n_target,1)];
    ub = [Inf*ones(l,1);
           ones(n_target,1)];
    nonlcon = [];
    options = optimset('TolFun',tolFun,...%'MaxFunEvals',max(4*l,3000),...                 
        'MaxFunEvals',min(max_ite(1)*l,max_ite(2)),...   % min(4*l,5000)
        'GradObj','on','Algorithm','interior-point',...
        'Hessian','user-supplied','SubproblemAlgorithm','cg',...
        'HessMult',@HessMultFcn,...
        'DerivativeCheck','off'); 
       % 3000: the default value of 'MaxFunEvals' for interior-point method
       % 'DerivativeCheck': whether to check the user-provided derivatives
    %if verbose<=1
        options = optimset(options,'Display','off');
    %end        
    
    % solve    
    x = fmincon(@fun,x0,A,b,Aeq,beq,lb,ub,nonlcon,options);

    % outputs:    
    sol.theta_index = i_target;
    sol.theta = x(l+1:l+n_target);
    sol.alpha = x(1:l);
    sol.b = 0; %  SVM in the primal: f(x) = \sum_{i} \alpha_i k(x_i, x);
end