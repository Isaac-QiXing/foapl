function varargout = problemArg(varargin)
% get the value of the specified argument
% Inputs:
%   varargin{i}: string indicating the argument name;
% Outputs:
%  varargout{i}: the value of the argument indicated by varargin{i};



% get arguments  set by users 

config();
    
% ============= arguments to be set by users =====================

mode_debug = 0; %1; % debug_mode

% % % % paths
% % % 
% % %        
% % % path_user_data = ['.' filesep]; % current folder
% % %                  % directory of users' PSM data files 
% % %                  % for linux system, e.g.  '/media/data';
% % %                  % for windows system, e.g., 'E:\data';
% % %                  % bias: '-path'
% % %                    
% % % path_foapl_data = ['.' filesep];          
% % %     % path_foapl_data: path to store data and result files produced by
% % %     % C-Ranker          

% % % % arguments for reading data from data files
% % % 
% % % delimiter = ' \b\t';  % bias: '-l'
% % % % %delimiter = ',';
% % % 
% % % decoyPrefix = 'Reverse'; % bias: '-p'
% % % 
% % % sheet = 'sheet1'; 
% % % 
% % % titleRow = 1;     % bias: '-w'      
    
% % % % arguments for splitting the data to train set and test set
% % % train_test_rate = 1/1;   % cardinality of train set / cardinality of test set
% % %                          % bias: '-t' 
% % % 
% % % fdr = 0.05;  %  FDR level, bias: '-fdr'
% % % 
% % % verbose = 2; % bias: '-v'
% % %   % 0: do not print any iteration/calculation and warning information to command window;  
% % %   % 1: put out iteration progress and warnings;
% % %   % 2: put out warnings and progress information briefly to command window;
% % %   % 3: put out more detailed iteration information to command window;
 

    
% % % % ---- arguments for C-Ranker model ----
% % % 
% % % c1 = 1.0; % the weight of the training error, bias: '-c1'
% % % 
% % % c2 = 1.0*c1; % the weight for encouraging that more target PSMs are shot;
% % %              %   it is recommended that c2 located in the interval (0, c1];
% % %              %   bias: '-c2'
% % % 
% % % kernelType = 'rbf'; % kernel type, 'rbf': RBF (Gaussian) kernel
% % %              
% % % 
% % % r1 =  1.0; %  kernel argument, bias: '-r'
% % % 
% % % flag_split_train_test = 1;
% % %     % 1 or 0: whether split the samples into train set and test set
% % %     % bias: '-f'
% % % 
% % % flag_standardize = 1;
% % %     % 1 or 0: whether standardize the columns of feature values
% % %     %   i.e. transform each column of the values to be zero-mean and unit
% % %     %   variance
% % %     % bias: '-g'
% % %     
% % % flag_w = 'manual';     
% % %     
% % %     
% % % % % % svm_theta_solver = 'matlabBuildIn'; 
% % % % % %     % solver of C-Ranker model
% % % % % %     % 'matlabBuildIn': using matlab build-in optimization tools
% % %   
% % % return_submodel = 0; 
% % %     % whether to return the submodels (or the corresponding scores)
% % %     
% % % flag_low_rank_approx = 1;
% % %     % whether approximate the kernel matrix K = G*G' by Cholesky factorization
% % %     %   where K is the kernel matrix, G is a low rank matrix
% % % tol_low_rank_approx = 1.0E-3;%1.0E-3
% % %     % tolence to do the Cholesky factorization
% % %     %       K = G*G'
% % %     %   the factorization terminates if the diagnal elements of the matrix
% % %     %     G decreased to this given tolerance;
% % %    
% % % maxTrainSize = 20000;
% % %     % maximum number of samples for training a submodel;
% % %     % bias: '-z'
% % % 
% % % num_submodel = 5;
% % %     % maximum number of submodels: C-Ranker calculate the scores of PSMs
% % %     %   by combining the scores of certain number of submodels;
% % %     % bias: '-m'
 


  
    
% ============= arguments set by C-Ranker ===============================

% It is strongly recommended that users DO NOT change these following
%   values of variables. But if users have insteresting to test or know
%   C-Ranker more (or already know much), of course, every variable is now
%   before your eyes. 
% =======================================================================

basic_feature_weight = 0.5; %  feature weights
weight_xcorr = 2.0;
  % the relative feature weight of xcorr and deltacn
  % bias: '-x'

% arguments for reading data from data files
getDataType = 'total';

getOneColumn = '';

fileType = '';

% paths

% path_str: the directory of the code of C-Ranker  
if ismember('path_foapl',varargin) 
    currentDepth = 1;
        % the current path depth (compared with the path of C-Ranker)
    argPath = struct ('depth',currentDepth,'flag_reserve_split_char',0);
    currPath = fileparts(mfilename('fullpath')); % get current path    
    path_foapl = parentDir(currPath,argPath);
end

% % % if ismember('path_foapl_data_sample',varargin)
% % %     path_foapl_data_sample = ...
% % %         [removeFileSep(path_foapl_data) filesep 'foapl_data'];
% % %     % directory to store files of PSM samples produced by C-Ranker    
% % % end
% % % if ismember('path_foapl_result',varargin)
% % %     path_foapl_result = ...
% % %         [removeFileSep(path_foapl_data) filesep 'foapl_result'];
% % %     % directory to store results of C-Ranker
% % % end
% % % path_foapl_result = path_foapl_data;  %%%remove this  variable
% % %     % directory to store results of C-Ranker, 



 % feature names 
 
 % -----------  features ------------------- 

% % % %   the spell of these feature names should coincide with that in the title
% % % %   row of the given PSMs data file  
% % % feature_name_spectrum = 'spectrum';  % name of spectrum feature 
% % % feature_name_peptide = 'peptide'; %  name of peptide feature 
% % % feature_name_protein = 'protein'; % name of protein feature 
% % % feature_name_xcorr = 'xcorr'; %  name of xcorr feature
% % % feature_name_deltacn = 'deltacn'; %  name of deltacn feature
% % % feature_name_ions = 'ions'; % name of ions feature
% % % 
% % % feature_name_enzN = 'enzN';
% % % feature_name_enzC = 'enzC';
% % % feature_name_numProt = 'numProt';
% % % feature_name_xcorrR = 'xcorrR';
% % % 
% % % feature_name_label = 'label'; % name of the label 
% % % feature_name_peptide_len = 'peptide_len';


feature_name_digest_type = 'digest_type';
feature_name_psm_id = 'id';
feature_name_psm_score = 'score';

 %   the features consists of two parts:
 %    (1) the features of original data (contained in the given data file),
 %        which contains 
 %          a. the basic features: ones that used for the peptide
 %             identification algorithm;
 %          b. the other features;
 %          Both of these features may be numeric or strings.
 %   (2) the calculated (user-defined) features 
 %        the ones that calculated based on the original features values; 

% % % feature_origin_basic_numeric = {}; 
% % %     % original in basic features of numeric value
% % % feature_origin_basic_string = {feature_name_protein}; 
% % %     % original basic features of string value;
% % %     % it is recommended that feature_origin_basic_string at least contain
% % %     %   the feature  protein;
% % % 
% % % feature_origin_append_numeric = {feature_name_xcorr,feature_name_deltacn,...
% % %        'sprank',feature_name_ions,'hit_mass'};
% % %     % other original features of numeric values
% % %     % If users have numerical data of other features to be added to train
% % %     %   the model (or do not want to use the features listed currently),
% % %     %   just revise this setting; 
% % %     
% % %     
% % % feature_origin_append_string  = {feature_name_spectrum,feature_name_peptide};
% % %     % other original features of string values
    
% % % feature_calculate_numeric = {feature_name_enzN,feature_name_enzC,...
% % %     feature_name_numProt,feature_name_xcorrR};
% % %     % features calculated based on the original feature values;
% % %     %   these values of the feature will be used to train the model;
% % %     % If users do not want to use some of the features listed currently,
% % %     %   remove them from the current cetting;
    
    
    
feature_calculate_numeric_remain = {feature_name_digest_type};
    % remain calculated numeric features  (not used to train or predict the
    %   model), these features serve for other analysis and application;

feature_origin_numeric = ...
    [feature_origin_basic_numeric, feature_origin_append_numeric];
    % original (saved in data file) numeric features
    
feature_origin_string = ...
    [feature_origin_basic_string, feature_origin_append_string];
    % original (saved in data file) string features

feature_numeric_model = [feature_origin_numeric feature_calculate_numeric];
    % numeric features to train the model

% assign id of the numeric features 
for ii=1:length(feature_numeric_model)
    eval(sprintf('%s.id = %d;',feature_numeric_model{ii},ii));
end
    % the order of the features in the data matrix depends on the setting
    % order in this file 

    
  
% % % feature_weight_numeric_model = ...
% % %     ones(length(feature_numeric_model),1)*basic_feature_weight;
% % % % assign the feature weights of xcorr, deltacn
% % % if ismember(feature_name_xcorr,feature_numeric_model)
% % %     feature_weight_numeric_model(eval([feature_name_xcorr '.id'])) = ...
% % %         2.0*basic_feature_weight;
% % % end
% % % if ismember(feature_name_deltacn,feature_numeric_model)
% % %     feature_weight_numeric_model(eval([feature_name_deltacn '.id'])) = ...
% % %         2.0*basic_feature_weight;
% % % end


% ---- arguments for C-Ranker model ----

lb_reliable_score = 0.5; 
    % the lower bound of the score for a reliable target PSM 
    %   this argument is used to choose reliabls PSMs to calculate the 
    %   feature weights

decoy_rate = 0.5; %  number of decoy sample / whole number of samples
                  %    for training each sub-model

num_submodel_preliminary = 1; 
    % number of submodels for identifying some preliminary reliable targets
    
max_ite_num_foapl = [4, 6000]; 
    % a vector of 2 elements indicates the maximum iteration number 
    %  E.g. [4, 5000] indicates the maximum iteration number to solve 
    %   each submodel is 
    %               min(4*l,6000)
    %   where l is the number of the samples to train the submodel

    
% ----- arguments to calculate the scores of samples  -----


blockSize = 800; 
    % calculate the scores of the samples in a given set block by block,
    % blockSize is the size of the block

rate_trim_score = 0; %0.15
    % exclude rate_trim_score * 100% maximum values and
    %   rate_trim_score * 100 minimum values of scores produced by
    %   submodels for each sample;

coef_score = 3.0;
    % argument to calculate the score
    %  score= (2/pi)*sign(fx).*atan(coef_score*abs(fx));   
    % NOTE: if the value of this argument (coef_score) is changed, it is
    % recommended  that user restart Matlab to make the change effective;
   
    
% ---------------------------------------------
%  arguments to calculate the feature weights    
% ---------------------------------------------

c = c1; 
        % the weight of the training error in the model for solving the 
        % feature weights
        
maxTrainSize_feature_weight = 600; 
    % maximum number of samples for training  a sub-model of feature
    % weights

num_submodel_feature_weight = 12; %2;
    % number of sub-models for solving the feature weights
        
    
negative_rate_feature_weight = 0.5;
    %  number of negative sample / whole number of samples
    %    for choosing samples of each sub-model of the feature weights

rate_trim_feature_weight = 0.30;
    % exclude rate_trim_weight*100% maximum observed values and 
    %   rate_trim_weight*100% minimum observed values of weight for each
    %   feature;

max_ite_feature_weight = [5, 3000]; 
    % a vector of 2 elements indicates the maximum iteration number 
    %   to solve the each submodel of the feature weights
    %  E.g. [5, 3000] indicates the maximum iteration number is 
    %               max(5*n,3000)
    %   where n denotes the number of the samples to train the submodel

% % % % ----     parameters of online CS-Ranker algorithm -- 
% % % tol_violating_pair = 0.5; % initial value of  tol_violating_pair

% user set arguments 
userSetting();


% put out
for ii=1:nargin
    if exist(varargin{ii},'var')
        varargout{ii} = eval(varargin{ii});
    else
        varargout{ii} = [];
    end
end

end

