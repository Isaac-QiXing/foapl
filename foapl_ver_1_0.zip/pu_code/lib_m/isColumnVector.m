function flag = isColumnVector(v)  
    flag = isvector(v)&&size(v,2)<=1;
end